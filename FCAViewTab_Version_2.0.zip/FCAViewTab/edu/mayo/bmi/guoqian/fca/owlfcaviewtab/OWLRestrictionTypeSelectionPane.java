package edu.mayo.bmi.guoqian.fca.owlfcaviewtab;

/**
 * <p>�^�C�g��: FCAView Tab</p>
 *
 * <p>����: Context-based ontolgoy building using formal concept analysis</p>
 *
 * <p>���쌠: Copyright (c) 2005</p>
 *
 * <p>��Ж�: Department of Medical Informatics, Hokkaido University Graudate
 * School of Medicine</p>
 *
 * @author ������
 * @version 1.0
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import edu.mayo.bmi.guoqian.fca.fcaviewtab.*;
import edu.mayo.bmi.guoqian.fca.sct.*;

public class OWLRestrictionTypeSelectionPane
    extends JDialog implements ActionListener {

  private JLabel label;

  private JRadioButton jrbAllValuesFrom;
  private JRadioButton jrbSomeValuesFrom;
  private JRadioButton jrbOthers;

  private ButtonGroup bg;

  private JButton btnOK;

  private int typeIndex;

  public OWLRestrictionTypeSelectionPane() {

    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      initUI();
      this.setSize(400, 300);
      this.setResizable(true);
      this.setTitle("Type Selection");
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  private void initUI() throws Exception {
    this.getContentPane().setLayout(new BorderLayout());
    label = new JLabel("  Restriction Type: ");

    jrbAllValuesFrom = new JRadioButton("AllValuesFrom                    ");
    jrbAllValuesFrom.setSelected(true);
    jrbSomeValuesFrom = new JRadioButton("SomeValuesFrom                  ");
    jrbOthers = new JRadioButton("Others                              ");
    bg = new ButtonGroup();
    bg.add(jrbAllValuesFrom);
    bg.add(jrbSomeValuesFrom);
    bg.add(jrbOthers);


    JPanel jrbAttrPanel = new JPanel(new GridLayout(3, 1));
    jrbAttrPanel.add(jrbAllValuesFrom);
    jrbAttrPanel.add(jrbSomeValuesFrom);
    jrbAttrPanel.add(jrbOthers);


    JPanel jrbPanel = new JPanel(new BorderLayout());
    jrbPanel.add(label, BorderLayout.NORTH);
    jrbPanel.add(jrbAttrPanel, BorderLayout.CENTER);


    btnOK = new JButton("OK...");
    btnOK.addActionListener(this);
    JPanel okPanel = new JPanel();
    okPanel.add(btnOK);

    this.getContentPane().add(jrbPanel, BorderLayout.CENTER);
    this.getContentPane().add(okPanel, BorderLayout.SOUTH);

  }

  //�E�B���h�E������ꂽ�Ƃ��ɏI������悤�ɃI�[�o�[���C�h
  protected void processWindowEvent(WindowEvent e) {
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      cancel();
    }
    super.processWindowEvent(e);
  }

  //�_�C�A���O�����
  void cancel() {
    dispose();
  }

  public void actionPerformed(ActionEvent e) {
    Object s = e.getSource();

    if (s == btnOK) {

      if (jrbAllValuesFrom.isSelected()) {
        typeIndex = 0;
      }
      if (jrbSomeValuesFrom.isSelected()) {
        typeIndex = 1;
      }

      if(jrbOthers.isSelected()){
        typeIndex = 2;
      }

    }

    cancel();
  }

  public int getTypeIndex() {
    return typeIndex;
  }

}
