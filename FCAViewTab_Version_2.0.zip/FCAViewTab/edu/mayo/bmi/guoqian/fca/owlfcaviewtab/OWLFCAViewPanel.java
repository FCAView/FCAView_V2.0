package edu.mayo.bmi.guoqian.fca.owlfcaviewtab;

/**
 * <p>�^�C�g��: FCAView Tab</p>
 *
 * <p>����: Context-based ontolgoy building using formal concept analysis</p>
 *
 * <p>���쌠: Copyright (c) 2005</p>
 *
 * <p>��Ж�: Department of Medical Informatics, Hokkaido University Graudate
 * School of Medicine</p>
 *
 * @author ������
 * @version 1.0
 */

import java.io.*;
import java.util.*;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protegex.owl.model.*;
import edu.stanford.smi.protegex.owl.ui.clsproperties.*;
import edu.stanford.smi.protegex.owl.ui.widget.*;
import javax.swing.JSplitPane;
import java.awt.BorderLayout;
import java.awt.GridLayout;

import conexp.core.*;
import conexp.frontend.*;
import java.awt.Dimension;
import java.awt.Point;
import javax.swing.filechooser.FileFilter;

import edu.mayo.bmi.guoqian.fca.fcaviewtab.*;
import edu.mayo.bmi.guoqian.fca.sct.*;

public class OWLFCAViewPanel
    extends JPanel implements ActionListener {

  private OWLModel kb;

  private JSplitPane mainPane;

  private JRadioButton jrbtnSpec1;
  private JRadioButton jrbtnSpec2;
  private JRadioButton jrbtnSpec3;
  private JRadioButton jrbtnSpec4;
  private JRadioButton jrbtnSpec5;
  private JRadioButton jrbtnSpec6;
  private JRadioButton jrbtnSpec7;
  private JRadioButton jrbtnSpec8;
  private JRadioButton jrbtnSpec9;//for code set

  private JButton btnStart;
  private JButton btnAnonymousNodes;
  private JButton btnSave;
  private JButton btnAddQuery;
  private JButton btnBatchQuery;

  private JTextField jtfCodeSetFile;
  private JButton btnAddCodeSet;
  private JTextArea textAreaMemo;

  private JPanel latticePanel;
  private JScrollPane scrollPane;

  final static int SPECIFICATION_ONE = 1;
  final static int SPECIFICATION_TWO = 2;
  final static int SPECIFICATION_THREE = 3;
  final static int SPECIFICATION_FOUR = 4;
  final static int SPECIFICATION_FIVE = 5;
  final static int SPECIFICATION_SIX = 6;
  final static int SPECIFICATION_SEVEN = 7;
  final static int SPECIFICATION_EIGHT = 8;
  final static int SPECIFICATION_NINE = 9;

  private Context formalcontext;
  private Lattice lattice;

  //private StringBuffer sbAnonymousNodes = new StringBuffer();

  public OWLFCAViewPanel(OWLModel kb) {
    this.kb = kb;
    this.initUI();
  }

  private void initUI() {
    JPanel leftPanel = new JPanel(new BorderLayout());

    JPanel jrbtnPanel = new JPanel(new GridLayout(8, 1));
    jrbtnSpec1 = new JRadioButton("For one property");
    jrbtnSpec1.setSelected(true);
    jrbtnSpec2 = new JRadioButton("For all asserted restrictions");
    jrbtnSpec3 = new JRadioButton("For all superclasses");
    jrbtnSpec4 = new JRadioButton("For all normal forms (As Template)");
    jrbtnSpec5 = new JRadioButton("For all normal forms (Original Context)");
    jrbtnSpec6 = new JRadioButton("For all normal forms (Completed Context)");
    jrbtnSpec7 = new JRadioButton("For lexical context (Code View)");
    jrbtnSpec8 = new JRadioButton("For lexical context (Lattice View)");
    jrbtnSpec9 = new JRadioButton("For all normal forms (Code Set)");

    ButtonGroup jrbtnGroup = new ButtonGroup();
    jrbtnGroup.add(jrbtnSpec1);
    jrbtnGroup.add(jrbtnSpec2);
    jrbtnGroup.add(jrbtnSpec3);
    jrbtnGroup.add(jrbtnSpec4);
    jrbtnGroup.add(jrbtnSpec5);
    jrbtnGroup.add(jrbtnSpec6);
    jrbtnGroup.add(jrbtnSpec7);
    jrbtnGroup.add(jrbtnSpec8);
    jrbtnGroup.add(jrbtnSpec9);

    jrbtnPanel.add(jrbtnSpec1);
    jrbtnPanel.add(jrbtnSpec2);
    jrbtnPanel.add(jrbtnSpec3);
    jrbtnPanel.add(jrbtnSpec4);
    jrbtnPanel.add(jrbtnSpec5);
    jrbtnPanel.add(jrbtnSpec6);
    jrbtnPanel.add(jrbtnSpec7);
    jrbtnPanel.add(jrbtnSpec8);
    jrbtnPanel.add(jrbtnSpec9);
    JPanel btnStartPanel = new JPanel();
    btnStart = new JButton("Start...");
    btnStart.addActionListener(this);
    btnStartPanel.add(btnStart);

    JPanel btnAnonymousNodesPanel = new JPanel();
    btnAnonymousNodes = new JButton("Anonymous Nodes...");
    btnAnonymousNodes.addActionListener(this);
    btnAnonymousNodes.setEnabled(false);
    btnAnonymousNodesPanel.add(btnAnonymousNodes);

    JPanel btnSavePanel = new JPanel();
    btnSave = new JButton("Save Context...");
    btnSave.addActionListener(this);
    btnSave.setEnabled(false);
    btnSavePanel.add(btnSave);

    JPanel btnAddQueryPanel = new JPanel();
    btnAddQuery = new JButton("Query...");
    btnAddQuery.addActionListener(this);
    btnAddQuery.setEnabled(false);
    btnAddQueryPanel.add(btnAddQuery);

    btnBatchQuery = new JButton("Batch Query...");
    btnBatchQuery.addActionListener(this);
    btnBatchQuery.setEnabled(false);
    btnAddQueryPanel.add(btnBatchQuery);

    JPanel btnTwoPanel = new JPanel(new GridLayout(4, 1));
    btnTwoPanel.add(btnStartPanel);
    btnTwoPanel.add(btnAnonymousNodesPanel);
    btnTwoPanel.add(btnSavePanel);
    btnTwoPanel.add(btnAddQueryPanel);

    JPanel upperPanel = new JPanel(new BorderLayout());
    upperPanel.add(jrbtnPanel, BorderLayout.CENTER);
    upperPanel.add(btnTwoPanel, BorderLayout.SOUTH);

    JPanel centerPanel = new JPanel(new BorderLayout());

    JLabel labelCodeSet = new JLabel("File:");
    jtfCodeSetFile = new JTextField(20);
    jtfCodeSetFile.setText("/home/m005994/codeset.txt");
    btnAddCodeSet = new JButton("Add CodeSet...");
    btnAddCodeSet.addActionListener(this);
    JPanel panelCodeSet = new JPanel();
    panelCodeSet.add(labelCodeSet);
    panelCodeSet.add(jtfCodeSetFile);
    panelCodeSet.add(btnAddCodeSet);

    JLabel label = new JLabel("Processing report: ");

    textAreaMemo = new JTextArea();
    textAreaMemo.setEditable(false);
    textAreaMemo.setText("Please click the button above at first...");
    //textAreaMemo.setMinimumSize(new Dimension(400,600));
    JScrollPane memoPane = new JScrollPane();
    memoPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    memoPane.getViewport().add(textAreaMemo);

    //centerPanel.add(label, BorderLayout.NORTH);
    centerPanel.add(panelCodeSet, BorderLayout.NORTH);
    centerPanel.add(memoPane, BorderLayout.CENTER);

    leftPanel.add(upperPanel, BorderLayout.NORTH);
    leftPanel.add(centerPanel, BorderLayout.CENTER);

    leftPanel.setPreferredSize(new Dimension(300, 600));

    JPanel rightPanel = new JPanel();
    scrollPane = new JScrollPane();
    scrollPane.getViewport().add(rightPanel);
    //main pane to show left and right panel
    mainPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
                              true,
                              leftPanel,
                              scrollPane);
    mainPane.setOneTouchExpandable(true);

    this.setLayout(new BorderLayout());
    this.add(mainPane, BorderLayout.CENTER);

  }

  private int getProcessingIndex() {
    if (jrbtnSpec1.isSelected()) {
      return this.SPECIFICATION_ONE;
    }
    else if (jrbtnSpec2.isSelected()) {
      return this.SPECIFICATION_TWO;
    }
    else if (jrbtnSpec3.isSelected()) {
      return this.SPECIFICATION_THREE;
    }
    else if (jrbtnSpec4.isSelected()) {
      return this.SPECIFICATION_FOUR;
    }
    else if (jrbtnSpec5.isSelected()) {
      return this.SPECIFICATION_FIVE;
    }
    else if (jrbtnSpec6.isSelected()) {
      return this.SPECIFICATION_SIX;
    }
    else if(jrbtnSpec7.isSelected()){
      return this.SPECIFICATION_SEVEN;
    }else if (jrbtnSpec8.isSelected()){
      return this.SPECIFICATION_EIGHT;
    }else if(jrbtnSpec9.isSelected()){
      return this.SPECIFICATION_NINE;
    }else{
      return this.SPECIFICATION_ONE;
    }
  }

  public void actionPerformed(ActionEvent e) {
    Object s = e.getSource();

    int processingindex = this.getProcessingIndex();

    //if the selection button is clicked
    if (s == btnStart && processingindex == this.SPECIFICATION_ONE) {
      this.actionPerformed_Spec1();
      btnSave.setEnabled(true);
    }

    if (s == btnStart && processingindex == this.SPECIFICATION_TWO) {
      this.actionPerformed_Spec2();
      btnSave.setEnabled(true);
    }

    if (s == btnStart && processingindex == this.SPECIFICATION_THREE) {
      this.actionPerformed_Spec3();
      btnSave.setEnabled(true);
    }

    if (s == btnStart && processingindex == this.SPECIFICATION_FOUR) {
      this.actionPerformed_Spec4();
      btnSave.setEnabled(true);
    }

    if (s == btnStart && processingindex == this.SPECIFICATION_FIVE) {
      this.actionPerformed_Spec5();
      btnSave.setEnabled(true);
    }

    if (s == btnStart && processingindex == this.SPECIFICATION_SIX) {
      this.actionPerformed_Spec6();
      btnSave.setEnabled(true);
      btnAnonymousNodes.setEnabled(true);
    }

    if (s == btnStart && processingindex == this.SPECIFICATION_SEVEN) {
      this.actionPerformed_Spec7(2);
      btnSave.setEnabled(true);
     // btnAnonymousNodes.setEnabled(true);
      btnAddQuery.setEnabled(true);
      btnBatchQuery.setEnabled(true);
    }

    if (s == btnStart && processingindex == this.SPECIFICATION_EIGHT) {
      //this.actionPerformed_Spec7(3);
      this.actionPerformed_Spec7(2);
      btnSave.setEnabled(true);
      //btnAnonymousNodes.setEnabled(true);
      btnAddQuery.setEnabled(true);
      //btnBatchQuery.setEnabled(true);
    }
    if (s == btnStart && processingindex == this.SPECIFICATION_NINE) {
      //this.actionPerformed_Spec7(3);
      this.actionPerformed_Spec9();
      //btnSave.setEnabled(true);
      //btnAnonymousNodes.setEnabled(true);
      //btnAddQuery.setEnabled(true);
      //btnBatchQuery.setEnabled(true);
    }



    if (s == btnSave) {
      this.actionPerformed_saveContext();
    }

    if (s == btnAnonymousNodes) {
      this.actionPeformed_showAnonymousNodes();
    }

    if (s == btnAddQuery && processingindex == this.SPECIFICATION_SEVEN) {
      this.actionPerformed_addQuery(2);
    }

    if (s == btnAddQuery && processingindex == this.SPECIFICATION_EIGHT) {
      //this.actionPerformed_addQuery(3);
      this.actionPerformed_addQueryLatticeView(2);

    }

    if (s == btnBatchQuery && processingindex == this.SPECIFICATION_SEVEN) {
      this.actionPerformed_batchQuery(2);
    }

    if (s == btnBatchQuery && processingindex == this.SPECIFICATION_EIGHT) {
      this.actionPerformed_batchQuery(3);

    }

    if(s == btnAddCodeSet){
      this.actionPerformed_AddCodeSet();
    }
  }

  //specification one for one property only
  private void actionPerformed_Spec1() {
    textAreaMemo.setText("");

    textAreaMemo.append("Please select a property..." + "\n");
    textAreaMemo.append("\n");

    //to select a property from a list of properties
    RDFProperty prop = OWLUI.pickRDFProperty(kb.getRDFProperties(),
                                             "Select a Property");

    textAreaMemo.append("The Selected Property: " + prop.toString() + "\n");
    textAreaMemo.append("\n");

    //to get a domain class
    //if the domain class is defined and only one then get it
    //else the domain class is set as "owl:Thing"
    Collection unionDomain = prop.getUnionDomain();
    RDFSClass domainClass;
    if (prop.isDomainDefined() && unionDomain.size() == 1) {
      domainClass = prop.getDomain(false);
    }
    else {
      domainClass = kb.getOWLNamedClass("owl:Thing");
    }

    textAreaMemo.append("Please select a class..." + "\n");
    textAreaMemo.append("\n");

    //to select a class within domain
    OWLNamedClass classFromDomain = OWLUI.pickOWLNamedClass(kb,
        Collections.singleton(domainClass), "Select a Class");

    textAreaMemo.append("The Selected Class: " + classFromDomain.toString() +
                        "\n");
    textAreaMemo.append("\n");

    //default: getting all subclasses of the selected class
    Collection allSubClses = classFromDomain.getNamedSubclasses(false);
    //int count = this.getOWLNamedClassCount(allSubClses);
    int count = allSubClses.size();

    while (count < 1) {
      JOptionPane.showMessageDialog(this,
                                    "Please Select a Class that has named subclasses",
                                    "Warning Message",
                                    JOptionPane.INFORMATION_MESSAGE);

      classFromDomain = OWLUI.pickOWLNamedClass(kb,
                                                Collections.singleton(
          domainClass), "Select a Class");
      allSubClses = classFromDomain.getNamedSubclasses(false);
      count = allSubClses.size();
    }

    textAreaMemo.append("Its named subclasses: " + "\n");
    for (Iterator it = allSubClses.iterator(); it.hasNext(); ) {
      RDFSClass subCls = (RDFSClass) it.next();
      textAreaMemo.append(subCls.getBrowserText() + "\n");
    }
    textAreaMemo.append("\n");

    textAreaMemo.append("Please select a restriction type..." + "\n");
    textAreaMemo.append("\n");

    int typeIndex = this.getRestrictionTypeIndex();
    textAreaMemo.append("Selected Restriction Type: " +
                        this.getRestrictionTypeByIndex(typeIndex) + "\n");
    textAreaMemo.append("\n");

    formalcontext = this.getContext(allSubClses, prop, null, typeIndex);
    latticePanel = new FormalLatticeComponentPanel(formalcontext);
    scrollPane.getViewport().add(latticePanel, null);
    latticePanel.setVisible(true);

    textAreaMemo.append("Showing Context...");
    textAreaMemo.append("\n");
  }

  //specification two for all asserted conditions
  private void actionPerformed_Spec2() {
    textAreaMemo.setText("");
    textAreaMemo.append("Please select a class..." + "\n");
    textAreaMemo.append("\n");

    RDFSClass domainClass = kb.getOWLNamedClass("owl:Thing");

    //to select a class within domain
    OWLNamedClass classFromDomain = OWLUI.pickOWLNamedClass(kb,
        Collections.singleton(domainClass), "Select a Class");

    textAreaMemo.append("The Selected Class: " + classFromDomain.toString() +
                        "\n");
    textAreaMemo.append("\n");

    //default: getting all subclasses of the selected class
    Collection allSubClses = classFromDomain.getNamedSubclasses(false);
    int count = allSubClses.size();

    while (count < 1) {
      JOptionPane.showMessageDialog(this,
                                    "Please Select a Class that has named subclasses",
                                    "Warning Message",
                                    JOptionPane.INFORMATION_MESSAGE);

      classFromDomain = OWLUI.pickOWLNamedClass(kb,
                                                Collections.singleton(
          domainClass), "Select a Class");
      allSubClses = classFromDomain.getNamedSubclasses(false);
      count = allSubClses.size();
    }

    textAreaMemo.append("Its named subclasses: " + "\n");
    for (Iterator it = allSubClses.iterator(); it.hasNext(); ) {
      RDFSClass subCls = (RDFSClass) it.next();
      textAreaMemo.append(subCls.getBrowserText() + "\n");
    }
    textAreaMemo.append("\n");

    formalcontext = this.getContext(allSubClses, null, null, 3);
    latticePanel = new FormalLatticeComponentPanel(formalcontext);
    scrollPane.getViewport().add(latticePanel, null);
    latticePanel.setVisible(true);

    textAreaMemo.append("Showing Context...");
    textAreaMemo.append("\n");

  }

  //specification three for all super classes
  private void actionPerformed_Spec3() {
    textAreaMemo.setText("");
    textAreaMemo.append("Please select a class..." + "\n");
    textAreaMemo.append("\n");

    RDFSClass domainClass = kb.getOWLNamedClass("owl:Thing");

    //to select a class within domain
    OWLNamedClass classFromDomain = OWLUI.pickOWLNamedClass(kb,
        Collections.singleton(domainClass), "Select a Class");

    textAreaMemo.append("The Selected Class: " + classFromDomain.toString() +
                        "\n");
    textAreaMemo.append("\n");

    //default: getting all subclasses of the selected class
    Collection allSubClses = classFromDomain.getNamedSubclasses(false);
    int count = allSubClses.size();

    while (count < 1) {
      JOptionPane.showMessageDialog(this,
                                    "Please Select a Class that has named subclasses",
                                    "Warning Message",
                                    JOptionPane.INFORMATION_MESSAGE);

      classFromDomain = OWLUI.pickOWLNamedClass(kb,
                                                Collections.singleton(
          domainClass), "Select a Class");
      allSubClses = classFromDomain.getNamedSubclasses(false);
      count = allSubClses.size();
    }

    textAreaMemo.append("Its named subclasses: " + "\n");
    for (Iterator it = allSubClses.iterator(); it.hasNext(); ) {
      RDFSClass subCls = (RDFSClass) it.next();
      textAreaMemo.append(subCls.getBrowserText() + "\n");
    }
    textAreaMemo.append("\n");

    formalcontext = this.getContext(allSubClses, null, null, 4);
    latticePanel = new FormalLatticeComponentPanel(formalcontext);
    scrollPane.getViewport().add(latticePanel, null);
    latticePanel.setVisible(true);

    textAreaMemo.append("Showing Context...");
    textAreaMemo.append("\n");
  }

  /**
   * specification four for all normal forms as termplate
   * May 17, 2006
   */

  private void actionPerformed_Spec4() {
    textAreaMemo.setText("");
    textAreaMemo.append("Please select a class..." + "\n");
    textAreaMemo.append("\n");

    RDFSClass domainClass = kb.getOWLNamedClass("owl:Thing");

    //to select a class within domain
    OWLNamedClass classFromDomain = OWLUI.pickOWLNamedClass(kb,
        Collections.singleton(domainClass), "Select a Class");

    textAreaMemo.append("The Selected Class: " + classFromDomain.toString() +
                        "\n");
    textAreaMemo.append("\n");

    //default: getting all subclasses of the selected class
    Collection allSubClses = classFromDomain.getNamedSubclasses(true);
    if (!classFromDomain.isDefinedClass()) {
      allSubClses.add(classFromDomain);
    }
    textAreaMemo.append("Its named subclasses: " + "\n");
    for (Iterator it = allSubClses.iterator(); it.hasNext(); ) {
      RDFSClass subCls = (RDFSClass) it.next();
      textAreaMemo.append(subCls.getBrowserText() + "\n");
    }
    textAreaMemo.append("\n");

    formalcontext = this.getContext(allSubClses, null, classFromDomain, 5);
    latticePanel = new FormalLatticeComponentPanel(formalcontext);
    scrollPane.getViewport().add(latticePanel, null);
    latticePanel.setVisible(true);

    textAreaMemo.append("Showing Context...");
    textAreaMemo.append("\n");

  }

  /**
   * specification five for all normal forms with values (incomplete)
   * May 18, 2006
   */
  private void actionPerformed_Spec5() {
    textAreaMemo.setText("");
    textAreaMemo.append("Please select a class..." + "\n");
    textAreaMemo.append("\n");

    RDFSClass domainClass = kb.getOWLNamedClass("owl:Thing");

    //to select a class within domain
    OWLNamedClass classFromDomain = OWLUI.pickOWLNamedClass(kb,
        Collections.singleton(domainClass), "Select a Class");

    textAreaMemo.append("The Selected Class: " + classFromDomain.toString() +
                        "\n");
    textAreaMemo.append("\n");

    //default: getting all subclasses of the selected class
    Collection allSubClses = classFromDomain.getNamedSubclasses(true);
    if (!classFromDomain.isDefinedClass()) {
      allSubClses.add(classFromDomain);
    }
    textAreaMemo.append("Its named subclasses: " + "\n");
    for (Iterator it = allSubClses.iterator(); it.hasNext(); ) {
      RDFSClass subCls = (RDFSClass) it.next();
      textAreaMemo.append(subCls.getBrowserText() + "\n");
    }
    textAreaMemo.append("\n");

    formalcontext = this.getContext(allSubClses, null, null, 6);
    latticePanel = new FormalLatticeComponentPanel(formalcontext);
    scrollPane.getViewport().add(latticePanel, null);
    latticePanel.setVisible(true);

    textAreaMemo.append("Showing Context...");
    textAreaMemo.append("\n");

  }

  /**
   * a sepecification for computing the completed context (May 19, 2006)
   * a query process was added at May 20, 2006
   */
  private void actionPerformed_Spec6() {
    textAreaMemo.setText("");
    textAreaMemo.append("Please select a class..." + "\n");
    textAreaMemo.append("\n");

    RDFSClass domainClass = kb.getOWLNamedClass("owl:Thing");

    //to select a class within domain
    OWLNamedClass classFromDomain = OWLUI.pickOWLNamedClass(kb,
        Collections.singleton(domainClass), "Select a Class");

    textAreaMemo.append("The Selected Class: " + classFromDomain.toString() +
                        "\n");
    textAreaMemo.append("\n");

    //default: getting all subclasses of the selected class
    Collection allSubClses = new ArrayList();

    allSubClses = classFromDomain.getNamedSubclasses(true);

    //if the selected class is not a defined class, add it as a subclass
    if (!classFromDomain.isDefinedClass()) {
      allSubClses.add(classFromDomain);
    }
    textAreaMemo.append("Its named subclasses: " + "\n");
    for (Iterator it = allSubClses.iterator(); it.hasNext(); ) {
      RDFSClass subCls = (RDFSClass) it.next();
      textAreaMemo.append(subCls.getBrowserText() + "\n");
    }
    textAreaMemo.append("\n");

    //adding a query selection process during computing the context
    int option = JOptionPane.showConfirmDialog(this,
                                               "Do you want to add an instance or a query?",
                                               "Add query?",
                                               JOptionPane.OK_CANCEL_OPTION);
    if (option == JOptionPane.OK_OPTION) {
      String queryName = JOptionPane.showInputDialog(this,
          "Please input the name of your query: ",
          "Query1");

      NormalForm selectedNormalForm = new NormalForm();
      NormalForm allNormalForms = this.getAllNormalForms(allSubClses);
      Iterator it = allNormalForms.getKeys().iterator();
      while (it.hasNext()) {
        String key = (String) it.next();
        Collection values = (Collection) allNormalForms.getValues(key);
        String[] valuesArray = this.getStringArray(values);
        if (valuesArray.length > 0) {
          String[] selectedValues =
              this.showAttrSelectionPane(valuesArray, "Select values", key);
          for (int i = 0; i < selectedValues.length; i++) {
            selectedNormalForm.put(key, selectedValues[i]);
          }
        }
      }

      formalcontext = this.getContextForQuery(allSubClses,
                                              queryName, selectedNormalForm, 8);

      latticePanel = new FormalLatticeComponentPanel(formalcontext);
      scrollPane.getViewport().add(latticePanel, null);
      latticePanel.setVisible(true);

      textAreaMemo.append("Showing Context...");
      textAreaMemo.append("\n");

    }
    else {

      formalcontext = this.getContext(allSubClses, null, null, 7);

      latticePanel = new FormalLatticeComponentPanel(formalcontext);
      scrollPane.getViewport().add(latticePanel, null);
      latticePanel.setVisible(true);

      textAreaMemo.append("Showing Context...");
      textAreaMemo.append("\n");
    }
  }
  private void actionPerformed_AddCodeSet(){
    BufferedReader br = null;
    String fileName = jtfCodeSetFile.getText();
    StringBuffer sb = new StringBuffer();
    try{
      br = new BufferedReader(new FileReader(fileName));
      String line = br.readLine();
      while(line != null){
        sb.append(line + "\n");
        line = br.readLine();
      }
      br.close();
      textAreaMemo.setText(sb.toString());
    }catch(IOException ie){
      ie.printStackTrace();
    }
  }


  private Collection getCodeSet(){
    Collection ret = new ArrayList();

    String allText = textAreaMemo.getText();
    String[] codeSet = allText.split("\n");
    for(int i = 0; i < codeSet.length; i++){
      String code = codeSet[i];
      RDFSClass domainClass = kb.getOWLNamedClass("SCTID_" + code);
      if(domainClass != null && !ret.contains(domainClass)){
        ret.add(domainClass);
      }
    }

    return ret;
  }

  /**
   * a sepecification for computing the completed context (May 19, 2006)
   * a query process was added at May 20, 2006
   */
  private void actionPerformed_Spec9() {

    Collection codes = this.getCodeSet();


    for (Iterator it = codes.iterator(); it.hasNext(); ) {
      RDFSClass subCls = (RDFSClass) it.next();
    }


      formalcontext = this.getContext(codes, null, null, 9);

      latticePanel = new FormalLatticeComponentPanel(formalcontext);
      scrollPane.getViewport().add(latticePanel, null);
      latticePanel.setVisible(true);

      textAreaMemo.append("Showing Context...");
      textAreaMemo.append("\n");

  }


  /**
   * a sepecification for computing the completed context (May 19, 2006)
   * a query process was added at May 20, 2006
   */
  private void actionPerformed_Spec7(int index) {
    textAreaMemo.setText("");
    textAreaMemo.append("Please select a class..." + "\n");
    textAreaMemo.append("\n");

    RDFSClass domainClass = kb.getOWLNamedClass("owl:Thing");

    //to select a class within domain
    OWLNamedClass classFromDomain = OWLUI.pickOWLNamedClass(kb,
        Collections.singleton(domainClass), "Select a Class");

    textAreaMemo.append("The Selected Class: " + classFromDomain.toString() +
                        "\n");
    textAreaMemo.append("\n");

    //default: getting all subclasses of the selected class
    Collection allSubClses = new ArrayList();

    allSubClses = classFromDomain.getNamedSubclasses(true);

    //if the selected class is not a defined class, add it as a subclass
    if (!classFromDomain.isDefinedClass()) {
      allSubClses.add(classFromDomain);
    }
    textAreaMemo.append("Its named subclasses: " + "\n");
    for (Iterator it = allSubClses.iterator(); it.hasNext(); ) {
      RDFSClass subCls = (RDFSClass) it.next();
      textAreaMemo.append(subCls.getBrowserText() + "\n");
    }
    textAreaMemo.append("\n");

    LexicalContextModel lcModel = new LexicalContextModel(index, kb, allSubClses);
    FormalContextAdapter adapter = lcModel.getContextAdapter();
    formalcontext = adapter.getContext();

    //formalcontext = this.getContext(allSubClses, null, null, 9);

    latticePanel = new FormalLatticeComponentPanel(formalcontext);
    scrollPane.getViewport().add(latticePanel, null);
    latticePanel.setVisible(true);

    textAreaMemo.append("Showing Context...");
    textAreaMemo.append("\n");

  }

  /**
   * save the current context into a csv file
   * so that could be seen in Excel
   * added at May 21, 2006
   */
  private void actionPerformed_saveContext() {
    BufferedWriter bw = null;
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setMultiSelectionEnabled(false);
    FileFilter filter = new CSVFileFilter();
    fileChooser.setFileFilter(filter);
    int ret = fileChooser.showSaveDialog(this);
    if (ret == JFileChooser.APPROVE_OPTION) {
      File file = fileChooser.getSelectedFile();
      if (!file.getName().endsWith(".csv")) {
        file = new File(file.getName() + ".csv");
      }

      try {
        bw = new BufferedWriter(new FileWriter(file));
        int objCount = formalcontext.getObjectCount();
        int attrCount = formalcontext.getAttributeCount();

        for (int i = 0; i < attrCount; i++) {
          ContextEntity attrEntity = formalcontext.getAttribute(i);
          bw.write("," + attrEntity.getName());
        }
        bw.write("\n");

        for (int j = 0; j < objCount; j++) {
          ContextEntity objEntity = formalcontext.getObject(j);
          bw.write(objEntity.getName());
          for (int k = 0; k < attrCount; k++) {
            if (formalcontext.getRelationAt(j, k)) {
              bw.write("," + "X");
            }
            else {
              bw.write(",");
            }
          }
          bw.write("\n");
        }
        bw.close();

      }
      catch (IOException ie) {
        ie.printStackTrace();
      }
    }
  }

  private void actionPeformed_showAnonymousNodes() {
    StringBuffer sb = new StringBuffer();
    StringBuffer sbcount = new StringBuffer();
    int count = lattice.conceptsCount();
    int aCount = 0;
    for (int i = 0; i < count; i++) {
      LatticeElement element = lattice.elementAt(i);
      //Concept concept = (Concept) element;
      if (!element.hasOwnObjects()) {
        if (i > 2) {
          aCount++;
          sb.append("Anonymous node " + aCount + ":\n");
          AnonymousNodeModel aNode = new AnonymousNodeModel(kb, element);
          sb.append(aNode.getObjectsOwnAttributesWithIds());

        }
      }
    }
    sbcount.append("There are totally " + aCount + " Anonymous Nodes.\n");
    JOptionPane.showMessageDialog(this,
                                  sbcount.toString(),
                                  "Anonymous Nodes Report",
                                  JOptionPane.PLAIN_MESSAGE);

    this.showAnonymousNodeListPane(sb.toString());
    //System.out.println(sb.toString());



  }

  //private static Lattice lattice = null;

  private void actionPerformed_addQuery(int index) {

    String queryContent = JOptionPane.showInputDialog(this,
        "Your Query: ",
        "Input Query");

    LexicalContextSetter setter = new LexicalContextSetter(index,
        formalcontext, queryContent);

    FormalContextAdapter adapter = setter.getContextAdapter();

    //formalcontext = adapter.getContext();

    Lattice _lattice = adapter.getLattice();

    LexicalContextQueryModel queryModel =
        new LexicalContextQueryModel(_lattice, kb);

    String queryResults = queryModel.getQueryResults();

    JOptionPane.showMessageDialog(this,
                                  queryResults,
                                  "SNOMED CT Codes",
                                  JOptionPane.INFORMATION_MESSAGE);

    textAreaMemo.append("Showing SNOMED CT Codes...");
    textAreaMemo.append("\n");

  }


  private void actionPerformed_addQueryLatticeView(int index) {

    String queryContent = JOptionPane.showInputDialog(this,
        "Your Query: ",
        "Input Query");

    LexicalContextSetter setter = new LexicalContextSetter(index,
        formalcontext, queryContent);

    FormalContextAdapter adapter = setter.getContextAdapter();

    formalcontext = adapter.getContext();

    latticePanel = new FormalLatticeComponentPanel(formalcontext);
    scrollPane.getViewport().add(latticePanel, null);
    latticePanel.setVisible(true);

    textAreaMemo.append("Showing Context...");
    textAreaMemo.append("\n");

  }

  //private static Lattice lattice = null;

  private void actionPerformed_batchQuery(int index) {

    StringBuffer sbResults = new StringBuffer();

    String fileName = JOptionPane.showInputDialog(this,
        "Input File Path: ",
        "c:\\temp\\heartmurmur02.txt");

    Vector sentences = this.getSentencesFromFile(fileName);
    for(int i = 0; i < sentences.size(); i++){
      String sentence = (String) sentences.elementAt(i);

      LexicalContextSetter setter = new LexicalContextSetter(index,
          formalcontext, sentence);

      FormalContextAdapter adapter = setter.getContextAdapter();

      //formalcontext = adapter.getContext();

      Lattice _lattice = adapter.getLattice();

      LexicalContextQueryModel queryModel =
          new LexicalContextQueryModel(_lattice, kb);

      String queryResults = queryModel.getQueryResults();

      sbResults.append(sentence + "\n");
      sbResults.append(queryResults + "\n");
    }
    this.saveResultsToFile(fileName, sbResults.toString());
    //JOptionPane.showMessageDialog(this,
    //                              sbResults.toString(),
    //                              "SNOMED CT Codes",
    //                              JOptionPane.INFORMATION_MESSAGE);

    textAreaMemo.append("Showing SNOMED CT Codes...");
    textAreaMemo.append("\n");

  }

  private Vector getSentencesFromFile(String fileName){
    Vector sentences = new Vector();
    BufferedReader br;
    try{
      br = new BufferedReader(new FileReader(fileName));
      String line = br.readLine();
      while(line != null){
        sentences.add(line);
        line = br.readLine();
      }
      br.close();
    }catch(IOException ie){
      ie.printStackTrace();
    }

    return sentences;
  }

  private void saveResultsToFile(String fileName, String contents){
    BufferedWriter bw;
    String rFileName = fileName.substring(0, fileName.length()-4) + "R.txt";
    try{
      bw = new BufferedWriter(new FileWriter(rFileName));
      bw.write(contents);
      bw.close();
    }catch(IOException ie){
      ie.toString();
    }
  }


  private void showAnonymousNodeListPane(String text) {
    AnonymoursNodeListPane aNodeListPane = new AnonymoursNodeListPane(text);
    Dimension dlgSize = aNodeListPane.getPreferredSize();
    Dimension frmSize = getSize();
    Point loc = getLocation();
    //aNodeListPane.setLocation( (frmSize.width - dlgSize.width) / 2 + loc.x,
    //(frmSize.height - dlgSize.height) / 2 + loc.y);
    aNodeListPane.setSize(dlgSize);
    aNodeListPane.setModal(true);
    aNodeListPane.pack();
    aNodeListPane.show();
  }

  /**
   * showing an attribute selection pane
   * @param attrs String[]
   * @param title String
   * @param label String
   * @return String[]
   */
  private String[] showAttrSelectionPane(String[] attrs, String title,
                                         String label) {
    FormalAttributesSelectionPane attrSelection =
        new FormalAttributesSelectionPane(attrs, title, label);

    Dimension dlgSize = attrSelection.getPreferredSize();
    Dimension frmSize = getSize();
    Point loc = getLocation();
    attrSelection.setLocation( (frmSize.width - dlgSize.width) / 2 + loc.x,
                              (frmSize.height - dlgSize.height) / 2 + loc.y);
    attrSelection.setModal(true);
    attrSelection.pack();
    attrSelection.show();
    String[] selectedAttributes = attrSelection.getSelectedItems();

    return selectedAttributes;
  }

  private String[] getStringArray(Collection col) {
    String[] ret = new String[col.size()];
    Iterator it = col.iterator();
    int i = 0;
    while (it.hasNext()) {
      String value = (String) it.next();
      ret[i++] = value;
    }

    return ret;
  }

  private NormalForm getAllNormalForms(Collection subClses) {
    NormalForm all = new NormalForm();
    Iterator it = subClses.iterator();
    while (it.hasNext()) {
      OWLNamedClass subCls = (OWLNamedClass) it.next();
      NormalForm subClsNormalForm = this.getNormalForm(subCls);
      Iterator it1 = subClsNormalForm.getKeys().iterator();
      while (it1.hasNext()) {
        String key = (String) it1.next();
        Collection values = (Collection) subClsNormalForm.getValues(key);
        all.put(key, values);
      }
    }

    return all;
  }

  private NormalForm getNormalForm(OWLNamedClass cls) {
    NormalFormDisplayFactory factory = new NormalFormDisplayFactory();
    NormalFormTransformModel model = factory.getModel(1, kb, cls);
    return model.getCanonicalForm();
  }

  private int getOWLNamedClassCount(Collection subclses) {
    int count = 0;
    Iterator it = subclses.iterator();
    while (it.hasNext()) {
      RDFSClass subcls = (RDFSClass) it.next();
      if (subcls instanceof OWLNamedClass) {
        count++;
      }
    }
    return count;
  }

  private int getRestrictionTypeIndex() {
    OWLRestrictionTypeSelectionPane attrSelection =
        new OWLRestrictionTypeSelectionPane();

    Dimension dlgSize = attrSelection.getPreferredSize();
    Dimension frmSize = getSize();
    Point loc = getLocation();
    attrSelection.setLocation( (frmSize.width - dlgSize.width) / 2 + loc.x,
                              (frmSize.height - dlgSize.height) / 2 + loc.y);
    attrSelection.setModal(true);
    attrSelection.pack();
    attrSelection.show();

    return attrSelection.getTypeIndex();
  }

  private String getRestrictionTypeByIndex(int typeIndex) {
    if (typeIndex == 0) {
      return "AllValuesFrom";
    }
    else if (typeIndex == 1) {
      return "SomeValuesFrom";
    }
    else if (typeIndex == 2) {
      return "Others";
    }
    else {
      return "Unknown";
    }
  }

  private Context getContext(Collection objects,
                             RDFProperty prop,
                             OWLNamedClass cls,
                             int typeIndex) {
    OWLFormalContextSetter setter =
        new OWLFormalContextSetter(kb,
                                   objects,
                                   prop,
                                   cls,
                                   null,
                                   null,
                                   typeIndex);
    FormalContextAdapter adapter = setter.getContextAdapter();
    lattice = adapter.getLattice();
    return adapter.getContext();

  }

  private Context getContextForQuery(Collection objects,
                                     String query,
                                     NormalForm selectedForm,
                                     int typeIndex) {
    OWLFormalContextSetter setter =
        new OWLFormalContextSetter(kb,
                                   objects,
                                   null,
                                   null,
                                   query,
                                   selectedForm,
                                   typeIndex);
    FormalContextAdapter adapter = setter.getContextAdapter();
    lattice = adapter.getLattice();
    return adapter.getContext();

  }

//a csv file filter added at May 21, 2006
  class CSVFileFilter
      extends FileFilter {

    public CSVFileFilter() {
    }

    public boolean accept(File file) {
      if (file.isDirectory()) {
        return true;
      }
      String filename = file.getName();

      int periodIndex = filename.lastIndexOf(".");

      boolean accepted = false;

      if (periodIndex > 0 && periodIndex < filename.length() - 1) {
        String extension = filename.substring(periodIndex + 1).toLowerCase();
        if (extension.equals("csv")) {
          accepted = true;
        }
      }

      return accepted;
    }

    public String getDescription() {
      return "CSV Files (*.csv)";
    }

  }

}
