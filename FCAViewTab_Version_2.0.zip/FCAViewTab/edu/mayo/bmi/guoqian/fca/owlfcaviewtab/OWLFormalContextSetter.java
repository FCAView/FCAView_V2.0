package edu.mayo.bmi.guoqian.fca.owlfcaviewtab;

/**
 * <p>�^�C�g��: FCAView Tab</p>
 *
 * <p>����: Context-based ontolgoy building using formal concept analysis</p>
 *
 * <p>���쌠: Copyright (c) 2005</p>
 *
 * <p>��Ж�: Department of Medical Informatics, Hokkaido University Graudate
 * School of Medicine</p>
 *
 * @author ������
 * @version 1.0
 */

import java.util.*;

import edu.stanford.smi.protegex.owl.model.*;
import edu.stanford.smi.protege.model.*;

import edu.mayo.bmi.guoqian.fca.fcaviewtab.*;
import edu.mayo.bmi.guoqian.fca.sct.*;

public class OWLFormalContextSetter {

  private FormalContextAdapter adapter;
  private OWLModel kb;

  public OWLFormalContextSetter(OWLModel kb,
                                Collection objects,
                                RDFProperty prop,
                                OWLNamedClass cls,
                                String query,
                                NormalForm selectedForm,
                                int typeIndex) {
    this.kb = kb;
    adapter = new FormalContextAdapter();
    switch (typeIndex) {
      case 0:
        this.setContextForAllValuesFrom(objects, prop);
        break;
      case 1:
        this.setContextForSomeValuesFrom(objects, prop);
        break;
      case 2:
        this.setContextForOthers(objects, prop);
        break;
      case 3:
        this.setContextForAllTypes(objects);
        break;
      case 4:
        this.setContextForAllSuperClasses(objects);
        break;
      case 5:
        this.setTemplateContextForAllNormalForms(objects, cls);
        break;
      case 6:
        this.setContextForAllNormalForms(objects);
        break;
      case 7:
        this.setCompletedContextForAllNormalForms(objects);
        break;
      case 8:
        this.setQueryCompletedContextForAllNormalForms(objects, query,
            selectedForm);
        break;
      case 9:
        this.setCompletedContextForCodeSets(objects);
        break;
      case 10:
        break;
      default:
        this.setContextForSomeValuesFrom(objects, prop);
        break;
    }

  }



  private void setQueryCompletedContextForAllNormalForms(Collection objects,
      String query, NormalForm selectedForm) {
    Iterator it1 = objects.iterator();
    while (it1.hasNext()) {
      OWLNamedClass namedCls = (OWLNamedClass) it1.next();
      String namedClsName = namedCls.getBrowserText();
      adapter.addFormalObject(namedClsName);
      NormalForm nForm = this.getNormalForm(namedCls);
      Collection keys = nForm.getKeys();
      Iterator it2 = keys.iterator();
      while (it2.hasNext()) {
        String key = (String) it2.next();
        Collection values = (Collection) nForm.getValues(key);
        Iterator it3 = values.iterator();
        while (it3.hasNext()) {
          String value = (String) it3.next();
          String keyvalue = value + "(" + key + ")";
          adapter.addFormalAttribute(keyvalue);
          adapter.setRelation(namedClsName, keyvalue);

          //complete context
          OWLNamedClass valueCls = kb.getOWLNamedClass(value);
          Collection valueSuperClses = valueCls.getNamedSuperclasses(true);
          Collection strCol = this.getStringCollectionForCls(valueSuperClses);
          Iterator it4 = objects.iterator();
          while (it4.hasNext()) {
            OWLNamedClass namedCls2 = (OWLNamedClass) it4.next();
            NormalForm nForm2 = this.getNormalForm(namedCls2);
            Collection key2 = nForm2.getKeys();
            if (key2.contains(key)) {
              Collection values2 = (Collection) nForm2.getValues(key);
              Iterator it5 = values2.iterator();
              while (it5.hasNext()) {
                String value2 = (String) it5.next();
                //System.out.println("value2:" + value2);
                //OWLNamedClass valueCls2 = kb.getOWLNamedClass(value2);
                if (strCol.contains(value2)) {
                  String keyvalue2 = value2 + "(" + key + ")";
                  //System.out.println("keyvalue: " + keyvalue2);
                  adapter.addFormalAttribute(keyvalue2);
                  adapter.setRelation(namedClsName, keyvalue2);
                }
              }
            }
          }
        }
      }
    }

    this.setQueryIntoContext(objects, query, selectedForm);
  }

  private void setQueryIntoContext(Collection objects, String query,
                                   NormalForm nForm) {
    adapter.addFormalObject(query);
    //NormalForm nForm = this.getNormalForm(namedCls);
    Collection keys = nForm.getKeys();
    Iterator it2 = keys.iterator();
    while (it2.hasNext()) {
      String key = (String) it2.next();
      Collection values = (Collection) nForm.getValues(key);
      Iterator it3 = values.iterator();
      while (it3.hasNext()) {
        String value = (String) it3.next();
        String keyvalue = value + "(" + key + ")";
        adapter.addFormalAttribute(keyvalue);
        adapter.setRelation(query, keyvalue);

        //complete context
        OWLNamedClass valueCls = kb.getOWLNamedClass(value);
        Collection valueSuperClses = valueCls.getNamedSuperclasses(true);
        Collection strCol = this.getStringCollectionForCls(valueSuperClses);
        Iterator it4 = objects.iterator();
        while (it4.hasNext()) {
          OWLNamedClass namedCls2 = (OWLNamedClass) it4.next();
          NormalForm nForm2 = this.getNormalForm(namedCls2);
          Collection key2 = nForm2.getKeys();
          if (key2.contains(key)) {
            Collection values2 = (Collection) nForm2.getValues(key);
            Iterator it5 = values2.iterator();
            while (it5.hasNext()) {
              String value2 = (String) it5.next();
              //System.out.println("value2:" + value2);
              //OWLNamedClass valueCls2 = kb.getOWLNamedClass(value2);
              if (strCol.contains(value2)) {
                String keyvalue2 = value2 + "(" + key + ")";
                //System.out.println("keyvalue: " + keyvalue2);
                adapter.addFormalAttribute(keyvalue2);
                adapter.setRelation(query, keyvalue2);
              }
            }
          }
        }
      }
    }
  }

  private void setCompletedContextForAllNormalForms(Collection objects) {

    //here objects are a set of selected concepts
    Iterator it1 = objects.iterator();
    while (it1.hasNext()) {
      OWLNamedClass namedCls = (OWLNamedClass) it1.next();
      String namedClsName = namedCls.getBrowserText();

      adapter.addFormalObject(namedClsName);

      //get normal for of a selected concept
      NormalForm nForm = this.getNormalForm(namedCls);

      //get a set of keys from the normal form
      Collection keys = nForm.getKeys();
      Iterator it2 = keys.iterator();
      while (it2.hasNext()) {

        //for each key
        String key = (String) it2.next();

        //a set of values for the key
        Collection values = (Collection) nForm.getValues(key);
        Iterator it3 = values.iterator();
        while (it3.hasNext()) {
          String value = (String) it3.next();

          //form a value-key pair
          String keyvalue = value + "(" + key + ")";
          adapter.addFormalAttribute(keyvalue);
          adapter.setRelation(namedClsName, keyvalue);

          //complete context
          OWLNamedClass valueCls = kb.getOWLNamedClass(value);
          //get all super classes for the value
          Collection valueSuperClses = valueCls.getNamedSuperclasses(true);
          Collection strCol = this.getStringCollectionForCls(valueSuperClses);

          //loop all classes again
          Iterator it4 = objects.iterator();
          while (it4.hasNext()) {
            OWLNamedClass namedCls2 = (OWLNamedClass) it4.next();
            NormalForm nForm2 = this.getNormalForm(namedCls2);
            Collection key2 = nForm2.getKeys();

            //keep in the same key section for complete
            if (key2.contains(key)) {
              Collection values2 = (Collection) nForm2.getValues(key);
              Iterator it5 = values2.iterator();
              while (it5.hasNext()) {
                String value2 = (String) it5.next();
                //System.out.println("value2:" + value2);
                //OWLNamedClass valueCls2 = kb.getOWLNamedClass(value2);

                //if
                if (strCol.contains(value2)) {
                  String keyvalue2 = value2 + "(" + key + ")";
                  //System.out.println("keyvalue: " + keyvalue2);
                  adapter.addFormalAttribute(keyvalue2);
                  adapter.setRelation(namedClsName, keyvalue2);
                }
              }
            }

            if (!key.equals("isA")) {
              RDFProperty keyProp = kb.getRDFProperty(key);
              //System.out.println(keyProp.getBrowserText());
              Collection supProps = new ArrayList();
              if (keyProp.getSuperproperties(false) != null) {
                //System.out.println("Debug: " + keyProp.getBrowserText());
                supProps = keyProp.getSuperproperties(false);

                //if a perporty has super properties
                //if(supProps.size() > 0){

                //change it to string collection
                Collection strProps = this.getStringCollectionForProp(supProps);
                Iterator itKey2 = key2.iterator();
                while (itKey2.hasNext()) {
                  String strKey2 = (String) itKey2.next();
                  //if the super properties contains another property
                  if (strProps.contains(strKey2)) {
                    //System.out.println("Debug: " + strKey2);
                    Collection valuesForStrKey2 = (Collection) nForm2.getValues(
                        strKey2);
                    //if they have the same value then set relation true
                    if (valuesForStrKey2.contains(value)) {
                      String strKey2Value = value + "(" + strKey2 + ")";
                      adapter.addFormalAttribute(strKey2Value);
                      adapter.setRelation(namedClsName, strKey2Value);

                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  private void setCompletedContextForCodeSets(Collection objects) {

    //here objects are a set of selected concepts
    Iterator it1 = objects.iterator();
    while (it1.hasNext()) {
      OWLNamedClass namedCls = (OWLNamedClass) it1.next();
      String namedClsName = namedCls.getBrowserText();
      String transName = this.getSctidForCls(namedClsName);
      adapter.addFormalObject(transName);

      //get normal for of a selected concept
      NormalForm nForm = this.getNormalForm(namedCls);

      //get a set of keys from the normal form
      Collection keys = nForm.getKeys();
      Iterator it2 = keys.iterator();
      while (it2.hasNext()) {

        //for each key
        String key = (String) it2.next();

        //a set of values for the key
        Collection values = (Collection) nForm.getValues(key);
        Iterator it3 = values.iterator();
        while (it3.hasNext()) {
          String value = (String) it3.next();

          String transValue = this.getSctidForCls(value);
          String transKey = key;
          if(!key.equals("isA")){
            transKey = this.getSctidForProp(key);
          }
          //form a value-key pair
          String keyvalue = transValue + "(" + transKey + ")";
          adapter.addFormalAttribute(keyvalue);
          adapter.setRelation(transName, keyvalue);

          //complete context
          OWLNamedClass valueCls = kb.getOWLNamedClass(value);
          //get all super classes for the value
          Collection valueSuperClses = valueCls.getNamedSuperclasses(true);
          Collection strCol = this.getStringCollectionForCls(valueSuperClses);

          //loop all classes again
          Iterator it4 = objects.iterator();
          while (it4.hasNext()) {
            OWLNamedClass namedCls2 = (OWLNamedClass) it4.next();
            NormalForm nForm2 = this.getNormalForm(namedCls2);
            Collection key2 = nForm2.getKeys();

            //keep in the same key section for complete
            if (key2.contains(key)) {
              Collection values2 = (Collection) nForm2.getValues(key);
              Iterator it5 = values2.iterator();
              while (it5.hasNext()) {
                String value2 = (String) it5.next();
                //System.out.println("value2:" + value2);
                //OWLNamedClass valueCls2 = kb.getOWLNamedClass(value2);

                //if
                if (strCol.contains(value2)) {

                  String transValue2 = this.getSctidForCls(value2);
                  String transKey2 = key;
                  if(!key.equals("isA")){
                    transKey2 = this.getSctidForProp(key);
                  }
                  String keyvalue2 = transValue2 + "(" + transKey2 + ")";
                  //System.out.println("keyvalue: " + keyvalue2);
                  adapter.addFormalAttribute(keyvalue2);
                  adapter.setRelation(transName, keyvalue2);
                }
              }
            }

            if (!key.equals("isA")) {
              RDFProperty keyProp = kb.getRDFProperty(key);
              //System.out.println(keyProp.getBrowserText());
              Collection supProps = new ArrayList();
              if (keyProp.getSuperproperties(false) != null) {
                //System.out.println("Debug: " + keyProp.getBrowserText());
                supProps = keyProp.getSuperproperties(false);

                //if a perporty has super properties
                //if(supProps.size() > 0){

                //change it to string collection
                Collection strProps = this.getStringCollectionForProp(supProps);
                Iterator itKey2 = key2.iterator();
                while (itKey2.hasNext()) {
                  String strKey2 = (String) itKey2.next();
                  //if the super properties contains another property
                  if (strProps.contains(strKey2)) {
                    //System.out.println("Debug: " + strKey2);
                    Collection valuesForStrKey2 = (Collection) nForm2.getValues(
                        strKey2);
                    //if they have the same value then set relation true
                    if (valuesForStrKey2.contains(value)) {

                      String transValue22 = this.getSctidForCls(value);
                      String transKey22 = this.getSctidForProp(strKey2);

                      String strKey2Value = transValue22 + "(" + transKey22 + ")";
                      adapter.addFormalAttribute(strKey2Value);
                      adapter.setRelation(transName, strKey2Value);

                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  private String getSctidForCls(String str){
      OWLNamedClass namedCls = kb.getOWLNamedClass(str);
      RDFProperty labelProperty = kb.getRDFSLabelProperty();
      RDFSLiteral value = (RDFSLiteral)namedCls.getPropertyValue(labelProperty);
      String ret = value.getString();
      return ret;
  }

  private String getSctidForProp(String str){
      RDFProperty namedCls = kb.getRDFProperty(str);
      RDFProperty labelProperty = kb.getRDFSLabelProperty();
      RDFSLiteral value = (RDFSLiteral)namedCls.getPropertyValue(labelProperty);
      String ret = value.getString();
      return ret;
  }

  private Collection getStringCollectionForCls(Collection superClses) {
    Collection ret = new ArrayList();
    Iterator it = superClses.iterator();
    while (it.hasNext()) {
      OWLNamedClass superCls = (OWLNamedClass) it.next();
      String str = superCls.getBrowserText();
      ret.add(str);
    }
    return ret;
  }

  private Collection getStringCollectionForProp(Collection superProps) {
    Collection ret = new ArrayList();
    Iterator it = superProps.iterator();
    while (it.hasNext()) {
      RDFProperty superProp = (RDFProperty) it.next();
      String str = superProp.getBrowserText();
      ret.add(str);
    }
    return ret;
  }

  private void setTemplateContextForAllNormalForms(Collection objects,
      OWLNamedClass cls) {

    //add five instances to the template
    for (int i = 1; i < 6; i++) {
      String instance = "instance" + i;
      adapter.addFormalObject(instance);
      NormalForm nForm1 = this.getNormalForm(cls);
      Collection keys1 = nForm1.getKeys();
      Iterator it = keys1.iterator();
      while (it.hasNext()) {
        String key = (String) it.next();
        Collection values = (Collection) nForm1.getValues(key);
        Iterator it3 = values.iterator();
        while (it3.hasNext()) {
          String value = (String) it3.next();
          String keyvalue = value + "(" + key + ")";
          adapter.addFormalAttribute(keyvalue);
          adapter.setRelation(instance, keyvalue);
        }
      }
    }
    Iterator it1 = objects.iterator();
    while (it1.hasNext()) {
      OWLNamedClass namedCls = (OWLNamedClass) it1.next();
      String namedClsName = namedCls.getBrowserText();
      //adapter.addFormalObject(namedClsName);
      NormalForm nForm = this.getNormalForm(namedCls);
      Collection keys = nForm.getKeys();
      Iterator it2 = keys.iterator();
      while (it2.hasNext()) {
        String key = (String) it2.next();
        Collection values = (Collection) nForm.getValues(key);
        Iterator it3 = values.iterator();
        while (it3.hasNext()) {
          String value = (String) it3.next();
          String keyvalue = value + "(" + key + ")";
          adapter.addFormalAttribute(keyvalue);
          //adapter.setRelation(namedClsName, keyvalue);
        }
      }
    }

  }

  private void setContextForAllNormalForms(Collection objects) {
    Iterator it1 = objects.iterator();
    while (it1.hasNext()) {
      OWLNamedClass namedCls = (OWLNamedClass) it1.next();
      String namedClsName = namedCls.getBrowserText();
      adapter.addFormalObject(namedClsName);
      NormalForm nForm = this.getNormalForm(namedCls);
      Collection keys = nForm.getKeys();
      Iterator it2 = keys.iterator();
      while (it2.hasNext()) {
        String key = (String) it2.next();
        Collection values = (Collection) nForm.getValues(key);
        Iterator it3 = values.iterator();
        while (it3.hasNext()) {
          String value = (String) it3.next();
          String keyvalue = value + "(" + key + ")";
          adapter.addFormalAttribute(keyvalue);
          adapter.setRelation(namedClsName, keyvalue);
        }
      }
    }

  }

  private NormalForm getNormalForm(OWLNamedClass cls) {
    NormalFormDisplayFactory factory = new NormalFormDisplayFactory();
    NormalFormTransformModel model = factory.getModel(1, kb, cls);
    return model.getCanonicalForm();
  }

  private void setContextForAllSuperClasses(Collection objects) {
    Iterator it1 = objects.iterator();
    while (it1.hasNext()) {
      OWLNamedClass objectCls = (OWLNamedClass) it1.next();
      //String label = this.getLabelStringForClass(objectCls);
      adapter.addFormalObject(objectCls);
      Collection allSuperClasses = objectCls.getNamedSuperclasses(true);
      Iterator it3 = allSuperClasses.iterator();
      while (it3.hasNext()) {
        RDFSClass superClass = (RDFSClass) it3.next();
        adapter.addFormalAttribute(superClass.getBrowserText());
        adapter.setRelation(objectCls,
                            superClass.getBrowserText());
      }

    }
  }

  private void setContextForAllTypes(Collection objects) {
    Iterator it1 = objects.iterator();
    while (it1.hasNext()) {
      OWLNamedClass objectCls = (OWLNamedClass) it1.next();
      //if(objectCls instanceof OWLNamedClass){
      adapter.addFormalObject(objectCls);
      Collection restrictions = ( (OWLNamedClass) objectCls).getRestrictions();
      Iterator it2 = restrictions.iterator();
      while (it2.hasNext()) {
        Collection allSuperClasses = objectCls.getNamedSuperclasses(true);
        Iterator it3 = allSuperClasses.iterator();
        while (it3.hasNext()) {
          RDFSClass superClass = (RDFSClass) it3.next();
          //adapter.addFormalAttribute(superClass.getBrowserText());
          //adapter.setRelation((OWLNamedClass)objectCls, superClass.getBrowserText());
        }
        OWLRestriction restriction = (OWLRestriction) it2.next();
        adapter.addFormalAttribute(restriction.getFillerText());
        adapter.setRelation( (OWLNamedClass) objectCls,
                            restriction.getFillerText());

      }
    }
  }

  private String getLabelStringForClass(RDFSClass cls) {
    RDFProperty labelProperty = kb.getRDFSLabelProperty();
    RDFSLiteral value = (RDFSLiteral) cls.getPropertyValue(labelProperty);
    String ret = value.getString() + "(" + cls.getBrowserText() + ")";
    return ret;
  }

  private void setContextForAllValuesFrom(Collection objects,
                                          RDFProperty prop) {
    Iterator it1 = objects.iterator();
    while (it1.hasNext()) {
      OWLNamedClass objectCls = (OWLNamedClass) it1.next();
      //if(objectCls instanceof OWLNamedClass){
      adapter.addFormalObject(objectCls);
      //System.out.println("domain: " + objectCls.getBrowserText());
      Collection attributeClses = (objectCls).getUnionRangeClasses(prop);
      if (attributeClses.size() > 0) {
        Iterator it2 = attributeClses.iterator();
        while (it2.hasNext()) {
          OWLNamedClass rangeCls = (OWLNamedClass) it2.next();
          adapter.addFormalAttribute(rangeCls);
          adapter.setRelation(objectCls, rangeCls);
          //System.out.println("range: " + rangeCls.getBrowserText());
        }
      }
      //}
    }

  }

  private void setContextForSomeValuesFrom(Collection objects,
                                           RDFProperty prop) {
    Iterator it1 = objects.iterator();
    while (it1.hasNext()) {
      OWLNamedClass objectCls = (OWLNamedClass) it1.next();
      //if(objectCls instanceof OWLNamedClass){
      adapter.addFormalObject(objectCls);
      Collection restrictions = ( (OWLNamedClass) objectCls).getRestrictions();
      Iterator it2 = restrictions.iterator();
      while (it2.hasNext()) {
        OWLRestriction restriction = (OWLRestriction) it2.next();
        if (restriction.getOnProperty().equals(prop) &&
            restriction instanceof OWLSomeValuesFrom) {
          adapter.addFormalAttribute(restriction.getFillerText());
          adapter.setRelation( (OWLNamedClass) objectCls,
                              restriction.getFillerText());
        }
      }
      //}
    }
  }

  private void setContextForOthers(Collection objects,
                                   RDFProperty prop) {
    Iterator it1 = objects.iterator();
    while (it1.hasNext()) {
      OWLNamedClass objectCls = (OWLNamedClass) it1.next();
      //if(objectCls instanceof OWLNamedClass){
      adapter.addFormalObject(objectCls);
      Collection restrictions = ( (OWLNamedClass) objectCls).getRestrictions();
      Iterator it2 = restrictions.iterator();
      while (it2.hasNext()) {
        OWLRestriction restriction = (OWLRestriction) it2.next();
        if (restriction.getOnProperty().equals(prop) &&
            ! (restriction instanceof OWLSomeValuesFrom) &&
            ! (restriction instanceof OWLAllValuesFrom)) {

          String restrictionName = "" + restriction.getOperator() +
              restriction.getFillerText();
          adapter.addFormalAttribute(restrictionName);
          adapter.setRelation( (OWLNamedClass) objectCls, restrictionName);
        }
      }
    }
    //}
  }

  public FormalContextAdapter getContextAdapter() {
    return this.adapter;
  }

}
