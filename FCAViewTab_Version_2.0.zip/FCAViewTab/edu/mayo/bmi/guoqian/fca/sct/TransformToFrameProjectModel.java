package edu.mayo.bmi.guoqian.fca.sct;

/**
 * <p>�^�C�g��: FCAView Tab</p>
 *
 * <p>����: Compositional Expression Issue of SNOMED CT Using Formal Concept
 * Analysis</p>
 *
 * <p>���쌠: Copyright (c) 2006</p>
 *
 * <p>��Ж�: Division of BioMedical Informatics, Myo Clinic College of
 * Medicine</p>
 *
 * @author Guoqian Jiang
 * @version 1.0
 */

import java.util.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

//import Protege-2000 API
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.ui.*;
import edu.stanford.smi.protegex.owl.model.*;
//import edu.stanford.smi.protegex.owl.ui.clsproperties.*;
import edu.stanford.smi.protegex.owl.ui.widget.*;
import java.io.File;
import java.io.IOException;
import java.io.FileWriter;
import java.io.BufferedWriter;

import edu.mayo.bmi.guoqian.fca.fcaviewtab.*;
import edu.mayo.bmi.guoqian.fca.owlfcaviewtab.*;

public class TransformToFrameProjectModel {

  private final static String projectName
      = "c:\\Racer\\snomedct\\TemplateModel\\HeartMurmur-sct-test1.pprj";

  private OWLNamedClass selectedCls;
  private OWLModel kb;

  public TransformToFrameProjectModel(OWLNamedClass selectedCls,
                                      OWLModel kb) {
    this.selectedCls = selectedCls;
    this.kb = kb;
  }

  public void performTransform(){
    this.projectTransform(selectedCls);
  }

  private void projectTransform(OWLNamedClass cls) {
    Collection errors = new ArrayList();
    Project project = new Project(projectName, errors);
    if (errors.size() == 0) {
      KnowledgeBase newkb = project.getKnowledgeBase();
      Cls root = newkb.getCls(":THING");
      Collection colRoot = new ArrayList();
      colRoot.add(root);

      String clsName = cls.getBrowserText();
      clsName = this.getNormalizedString(clsName);
      Cls hm = newkb.createCls(clsName, colRoot);
      Collection colHm = new ArrayList();
      colHm.add(hm);

      /*
             Collection colSubclses = cls.getNamedSubclasses(true);
             Iterator it = colSubclses.iterator();
             while(it.hasNext()){
        OWLNamedClass subcls = (OWLNamedClass) it.next();
        String subclsName = subcls.getBrowserText();
        newkb.createCls(subclsName, colHm);

             }
       */

      //Cls heartmurmur = newkb(cls.getBrowserText());

      //get slot names
      //Collection slotNames = this.getAllSlotsOfNormalForms(cls);

      //add slots to Cls heartmurmur
      //this.addSlotsToCls(newkb, heartmurmur, slotNames);

      //add subclasses to Cls heartmurmur
      this.addSubclassesToCls(cls, hm, newkb);


      project.save(errors);

    }
    else {
      System.out.println("The errors occurred.\n");
    }
  }

  private void addSubclassesToCls(OWLNamedClass cls, Cls theCls,
                                  KnowledgeBase newkb) {
    Collection directSupClses = new ArrayList();
    directSupClses.add(theCls);
    Collection directSubclses = cls.getNamedSubclasses(false);
    if (cls.isDefinedClass()) {
      directSubclses = this.removeDefinedClass(directSubclses, cls);
    }
    Iterator it = directSubclses.iterator();
    while (it.hasNext()) {
      OWLNamedClass dSubcls = (OWLNamedClass) it.next();
      String dSubclsStr = dSubcls.getBrowserText();
      dSubclsStr = this.getNormalizedString(dSubclsStr);
      if(!newkb.containsFrame(dSubclsStr)){
        Cls dCls = newkb.createCls(dSubclsStr, directSupClses);

        if ( (dSubcls.getNamedSubclasses(false)).size() > 0) {
          addSubclassesToCls(dSubcls, dCls, newkb);
        }
      }else{
        Cls dCls = newkb.getCls(dSubclsStr);
        dCls.addDirectSuperclass(theCls);
      }
    }

  }

  private String getNormalizedString(String clsName){
    String ret = clsName;
    int end = this.getLength(clsName);
    String id = this.getSctidForCls(ret);
    ret = ret.substring(0, ret.length()-end);
    ret = ret + "(" + id + ")";

    return ret;
  }

  private int getLength(String clsName){
    int ret = 0;
    if(clsName.endsWith("__finding_")){
      ret = 10;
    } else if (clsName.endsWith("__procedure_")){
      ret = 12;
    } else if (clsName.endsWith("__body_structure_")){
      ret = 17;
    } else if (clsName.endsWith("__qualifier_value_")){
      ret = 18;
    } else if (clsName.endsWith("__person_")){
      ret = 9;
    } else{
      ret = 10;
    }

    return ret;
  }

  private String getSctidForCls(String str){
    OWLNamedClass namedCls = kb.getOWLNamedClass(str);
    RDFProperty labelProperty = kb.getRDFSLabelProperty();
    RDFSLiteral value = (RDFSLiteral)namedCls.getPropertyValue(labelProperty);
    String ret = value.getString();
    return ret;
}


  private Collection removeDefinedClass(Collection colClses,
                                        OWLNamedClass definedCls) {
    Collection ret = new ArrayList();
    Iterator it = colClses.iterator();
    while (it.hasNext()) {
      OWLNamedClass theCls = (OWLNamedClass) it.next();
      if (!theCls.equals(definedCls)) {
        ret.add(theCls);
      }
    }

    return ret;
  }

  private void addSlotsToCls(KnowledgeBase newkb, Cls theCls,
                             Collection slotNames) {

    Iterator it = slotNames.iterator();
    while (it.hasNext()) {
      String slotName = (String) it.next();
      Slot slot = newkb.createSlot(slotName);
    }

  }

}
