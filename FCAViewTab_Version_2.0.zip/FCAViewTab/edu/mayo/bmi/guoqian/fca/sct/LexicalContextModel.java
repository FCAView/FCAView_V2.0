package edu.mayo.bmi.guoqian.fca.sct;

/**
 * <p>�^�C�g��: FCAView Tab</p>
 *
 * <p>����: Context-based ontolgoy building using formal concept analysis</p>
 *
 * <p>���쌠: Copyright (c) 2005</p>
 *
 * <p>��Ж�: Department of Medical Informatics, Hokkaido University Graudate
 * School of Medicine</p>
 *
 * @author ������
 * @version 1.0
 */

import edu.mayo.bmi.guoqian.fca.fcaviewtab.*;
import edu.mayo.bmi.guoqian.fca.owlfcaviewtab.*;


import java.util.*;

import edu.stanford.smi.protegex.owl.model.OWLNamedClass;
import edu.stanford.smi.protegex.owl.model.OWLModel;
import edu.stanford.smi.protegex.owl.model.RDFSLiteral;
import edu.stanford.smi.protegex.owl.model.RDFProperty;


/**
 *
 * <p>�^�C�g��: FCAView Tab</p>
 *
 * <p>����: Compositional Expression Issue of SNOMED CT Using Formal Concept
 * Analysis</p>
 *
 * <p>���쌠: Copyright (c) 2006</p>
 *
 * <p>��Ж�: Division of BioMedical Informatics, Myo Clinic College of
 * Medicine</p>
 *
 * @author Guoqian Jiang
 * @version 1.0
 *
 * The class is used to create a context using the SNOMED CT  codes of a domain
 * as the formal objects and the words descrbing the codes as the formal attributes.
 *
 */
public class LexicalContextModel {

  private FormalContextAdapter adapter;
  private OWLModel kb;

  public LexicalContextModel(int index, OWLModel kb, Collection objects) {
    this.kb = kb;
    adapter = new FormalContextAdapter();
    switch(index){
      case 1:
        this.setLexicalContextNameOption(objects);
        break;
      case 2:
        this.setLexicalContextIdOption(objects);
        break;
      case 3:
        this.setLexicalContextIdOptionBigram(objects);
        break;
      default:
        this.setLexicalContextIdOption(objects);
        break;
    }
  }

  private void setLexicalContextIdOptionBigram(Collection objects){
    Iterator it1 = objects.iterator();
    while (it1.hasNext()) {
      OWLNamedClass namedCls = (OWLNamedClass) it1.next();
      //String namedClsName = this.getLabelForCls(namedCls);
      String namedClsName = namedCls.getBrowserText();
      //adapter.addFormalObject(namedClsName);
      //Collection words = this.getAllIndividualWordsOfSuperClasses(objects, namedClsName);

      //String labels = this.getDescriptionsForCls(namedCls);
      Collection descriptions = this.getDescriptionsForEachCls(namedCls);
      Iterator it2 = descriptions.iterator();
      while(it2.hasNext()){
        String label = (String) it2.next();
        String objName = namedClsName + "|" + label;
        adapter.addFormalObject(objName);
        Collection words = this.getIndividualWordsIdOptionBigram(label);
        Collection stopWords = this.getStopWords();
        Iterator it3 = words.iterator();
        while (it3.hasNext()) {
          String word = (String) it3.next();
          if(!stopWords.contains(word)){
            adapter.addFormalAttribute(word);
            adapter.setRelation(objName, word);
          }
        }
      }
    }
  }


  private void setLexicalContextIdOption(Collection objects){
    Iterator it1 = objects.iterator();
    while (it1.hasNext()) {
      OWLNamedClass namedCls = (OWLNamedClass) it1.next();
      //String namedClsName = this.getLabelForCls(namedCls);
      String namedClsName = namedCls.getBrowserText();
      //adapter.addFormalObject(namedClsName);
      //Collection words = this.getAllIndividualWordsOfSuperClasses(objects, namedClsName);

      //String labels = this.getDescriptionsForCls(namedCls);
      Collection descriptions = this.getDescriptionsForEachCls(namedCls);
      Iterator it2 = descriptions.iterator();
      while(it2.hasNext()){
        String label = (String) it2.next();
        String objName = namedClsName + "|" + label;
        adapter.addFormalObject(objName);
        Collection words = this.getIndividualWordsIdOption(label);
        Collection stopWords = this.getStopWords();
        Iterator it3 = words.iterator();
        while (it3.hasNext()) {
          String word = (String) it3.next();
          if(!stopWords.contains(word)){
            adapter.addFormalAttribute(word);
            adapter.setRelation(objName, word);
          }
        }
      }
    }
  }

  private Collection getStopWords(){
    String[] stopWords = {"by", "out", "of", "on",
                          "at", "to", "and", "fro", "", " "};
    Collection ret = new ArrayList();
    for(int i = 0; i < stopWords.length; i++){
      ret.add(stopWords[i]);
    }

    return ret;
  }


  private String getLabelForCls(OWLNamedClass cls){
      RDFProperty labelProperty = kb.getRDFSLabelProperty();
      RDFSLiteral value = (RDFSLiteral)cls.getPropertyValue(labelProperty);
      //String ret = value.getString();
      return value.getString();
  }

  private String getDescriptionsForCls(OWLNamedClass cls){

      StringBuffer desc = new StringBuffer();
      //OWLNamedClass namedCls = kb.getOWLNamedClass(str);
      RDFProperty descProperty = kb.getRDFProperty("rdfs:description");
      //RDFSLiteral value = (RDFSLiteral)namedCls.getPropertyValue(labelProperty);
      Collection labels = cls.getPropertyValues(descProperty);
      Iterator it = labels.iterator();
      while(it.hasNext()){
        RDFSLiteral value = (RDFSLiteral) it.next();
        desc.append(value.getString() + " ");
      }

      return desc.toString();
  }

  private Collection getDescriptionsForEachCls(OWLNamedClass cls){
    Collection ret = new ArrayList();
    RDFProperty descProperty = kb.getRDFProperty("rdfs:description");
    //RDFSLiteral value = (RDFSLiteral)namedCls.getPropertyValue(labelProperty);
    Collection labels = cls.getPropertyValues(descProperty);
    Iterator it = labels.iterator();
    while(it.hasNext()){
      RDFSLiteral value = (RDFSLiteral) it.next();
      ret.add(value.getString());
    }

    return ret;

  }

  //set lexical context for a collection of objects
  private void setLexicalContextNameOption(Collection objects) {

    Iterator it1 = objects.iterator();
    while (it1.hasNext()) {
      OWLNamedClass namedCls = (OWLNamedClass) it1.next();
      String namedClsName = namedCls.getBrowserText();
      adapter.addFormalObject(namedClsName);
      //Collection words = this.getAllIndividualWordsOfSuperClasses(objects, namedClsName);
      Collection words = this.getIndividualWordsNameOption(namedClsName);
      Iterator it2 = words.iterator();
      while (it2.hasNext()) {
        String word = (String) it2.next();
        adapter.addFormalAttribute(word);
        adapter.setRelation(namedClsName, word);
      }

    }

  }


  private Collection getIndividualWordsIdOption(String expression) {
    Collection ret = new ArrayList();

    //normalization processing
    expression = expression.replaceAll("\\(", "");
    expression = expression.replaceAll("\\)", "");
    expression = expression.replaceAll("\\,", "");
    //expression = expression.substring(0, expression.length());
    String[] words = expression.split(" ");
    for (int i = 0; i < words.length; i++) {
      String word = words[i];

      //remove "-" as individual word
      if (!word.equals("-")) {

        if (word.indexOf("-") >= 0) {

          //add a compound word
          if (!ret.contains(word.toLowerCase())) {
            ret.add(word.toLowerCase());
          }

          //get individual words for a compound word
          String[] wordpair1 = word.split("-");
          for (int j = 0; j < wordpair1.length; j++) {
            if (!ret.contains(wordpair1[j].toLowerCase())) {
              ret.add(wordpair1[j].toLowerCase());
            }
          }
        }else if(word.indexOf("/") >= 0){
            //add a compound word
            if (!ret.contains(word.toLowerCase())) {
              ret.add(word.toLowerCase());
            }

            //get individual words for a compound word
            String[] wordpair2 = word.split("/");
            for (int k = 0; k < wordpair2.length; k++) {
              if (!ret.contains(wordpair2[k].toLowerCase())) {
                ret.add(wordpair2[k].toLowerCase());
              }
          }
        }
        else {
          if (!ret.contains(word.toLowerCase())) {
            ret.add(word.toLowerCase());
          }
        }
      }
    }

    return ret;
  }

  private Collection getIndividualWordsIdOptionBigram(String expression) {
    Collection ret = new ArrayList();
    Vector vecWords = new Vector();

    //normalization processing
    expression = expression.replaceAll("\\(", "");
    expression = expression.replaceAll("\\)", "");
    expression = expression.replaceAll("\\,", "");
    //expression = expression.substring(0, expression.length());
    String[] words = expression.split(" ");
    for (int i = 0; i < words.length; i++) {
      String word = words[i];

      //remove "-" as individual word
      if (!word.equals("-")) {

        vecWords.add(word.toLowerCase());
/*
        if (word.indexOf("-") >= 0) {

          //add a compound word
          if (!ret.contains(word.toLowerCase())) {
            ret.add(word.toLowerCase());
          }

          //get individual words for a compound word
          String[] wordpair1 = word.split("-");
          for (int j = 0; j < wordpair1.length; j++) {
            if (!ret.contains(wordpair1[j].toLowerCase())) {
              ret.add(wordpair1[j].toLowerCase());
            }
          }
        }else if(word.indexOf("/") >= 0){
            //add a compound word
            if (!ret.contains(word.toLowerCase())) {
              ret.add(word.toLowerCase());
            }

            //get individual words for a compound word
            String[] wordpair2 = word.split("/");
            for (int k = 0; k < wordpair2.length; k++) {
              if (!ret.contains(wordpair2[k].toLowerCase())) {
                ret.add(wordpair2[k].toLowerCase());
              }
          }
        }
        else {
          if (!ret.contains(word.toLowerCase())) {
            ret.add(word.toLowerCase());
          }
        }
*/

      }
    }

    //getting bigram
    if(vecWords.size() > 1){
      for (int ii = 1; ii < vecWords.size(); ii++) {
         String bigram = (String) vecWords.elementAt(ii-1) + " " +
             (String) vecWords.elementAt(ii);
         ret.add(bigram);
      }
    }
    return ret;
  }



  private Collection getIndividualWordsNameOption(String expression) {
    Collection ret = new ArrayList();
    //delete double "__" in an expression
    expression = expression.replaceAll("__", "_");
    expression = expression.substring(0, expression.length() - 1);
    String[] words = expression.split("_");
    for (int i = 0; i < words.length; i++) {
      String word = words[i];
      if (!word.equals("-")) {
        if (word.indexOf("-") >= 0) {

          //add a compound word
          if (!ret.contains(word.toLowerCase())) {
            ret.add(word.toLowerCase());
          }

          //get individual words for a compound word
          String[] wordpair = word.split("-");
          for (int j = 0; j < wordpair.length; j++) {
            if (!ret.contains(wordpair[j].toLowerCase())) {
              ret.add(wordpair[j].toLowerCase());
            }
          }
        }
        else {
          if (!ret.contains(word.toLowerCase())) {
            ret.add(word.toLowerCase());
          }
        }
      }
    }

    return ret;
  }

  private Collection getAllIndividualWordsOfSuperClasses(Collection objects,
      String expression) {
    Collection ret = new ArrayList();
    Collection colCls = this.getIndividualWordsNameOption(expression);
    ret.addAll(colCls);
    OWLNamedClass cls = kb.getOWLNamedClass(expression);
    Iterator it = objects.iterator();
    while (it.hasNext()) {
      OWLNamedClass namedCls = (OWLNamedClass) it.next();
      String namedClsName = namedCls.getBrowserText();
      if (cls.isSubclassOf(namedCls)) {
        Collection namedClsWords = this.getIndividualWordsNameOption(namedClsName);
        ret.addAll(namedClsWords);
      }
    }

    return ret;
  }

  public FormalContextAdapter getContextAdapter() {
    return this.adapter;
  }
}
