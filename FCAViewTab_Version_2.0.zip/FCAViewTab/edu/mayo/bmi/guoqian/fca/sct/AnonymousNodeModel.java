package edu.mayo.bmi.guoqian.fca.sct;

/**
 * <p>�^�C�g��: FCAView Tab</p>
 *
 * <p>����: Context-based ontolgoy building using formal concept analysis</p>
 *
 * <p>���쌠: Copyright (c) 2005</p>
 *
 * <p>��Ж�: Department of Medical Informatics, Hokkaido University Graudate
 * School of Medicine</p>
 *
 * @author ������
 * @version 1.0
 */

import conexp.core.*;
import java.util.*;
import edu.stanford.smi.protegex.owl.model.*;
import edu.stanford.smi.protegex.owl.ui.widget.*;

public class AnonymousNodeModel {

  private OWLModel kb;

  private LatticeElement element;

  private Collection objects = new ArrayList();


  public AnonymousNodeModel(OWLModel kb, LatticeElement element) {
    this.kb = kb;
    this.element = element;
    this.getObjectsForAnonymousNodes(element);
  }

  public String getObjectsNames(){
    StringBuffer sb = new StringBuffer();
    Iterator it = objects.iterator();
    while(it.hasNext()){
      String name = (String) it.next();
      sb.append(name + "\n");
    }
    return sb.toString();
  }

  public String getObjectsNameWithIds(){
    StringBuffer sb = new StringBuffer();
    Iterator it = objects.iterator();
    while(it.hasNext()){
      String name = (String) it.next();
      String id = this.getSctidForCls(name);
      sb.append(id + "|" + name + "\n");

    }
    return sb.toString();
  }

  public String getObjectsOwnAttributesWithIds(){
    StringBuffer sb = new StringBuffer();
    sb.append(this.getOwnAttributeLabel(element));
    sb.append(this.getObjectsNameWithIds());
    return sb.toString();
  }

  private String getOwnAttributeLabel(LatticeElement element){
    StringBuffer sb = new StringBuffer();
    Iterator it = element.ownAttribsIterator();
    while(it.hasNext()){
      ContextEntity entity = (ContextEntity) it.next();
      //String id = this.getSctidForCls(entity.getName());
      sb.append("Own Attribute: " + entity.getName() + "\n");
    }

    return sb.toString();
  }


  private String getSctidForCls(String str){
      OWLNamedClass namedCls = kb.getOWLNamedClass(str);
      RDFProperty labelProperty = kb.getRDFSLabelProperty();
      RDFSLiteral value = (RDFSLiteral)namedCls.getPropertyValue(labelProperty);
      String ret = value.getString();
      return ret;
  }


  private void getObjectsForAnonymousNodes(LatticeElement element) {
   LatticeElementCollection children = element.getChildren();
   Iterator itc = children.iterator();
   while (itc.hasNext()) {
     LatticeElement child = (LatticeElement) itc.next();
     if(child.getChildren().getSize() > 1){
       getObjectsForAnonymousNodes(child);
     }
     Iterator itchild = child.ownObjectsIterator();
     while (itchild.hasNext()) {
       ContextEntity obj = (ContextEntity) itchild.next();
       if(!objects.contains(obj.getName())){
         objects.add(obj.getName());
       }
     }
   }
}

}
