package edu.mayo.bmi.guoqian.fca.sct;

/**
 * <p>�^�C�g��: FCAView Tab</p>
 *
 * <p>����: Context-based ontolgoy building using formal concept analysis</p>
 *
 * <p>���쌠: Copyright (c) 2005</p>
 *
 * <p>��Ж�: Department of Medical Informatics, Hokkaido University Graudate
 * School of Medicine</p>
 *
 * @author ������
 * @version 1.0
 */
import java.util.*;

import conexp.core.*;

import edu.stanford.smi.protegex.owl.model.*;

import edu.mayo.bmi.guoqian.fca.fcaviewtab.*;
import edu.mayo.bmi.guoqian.fca.owlfcaviewtab.*;

public class LexicalContextSetter {

  private FormalContextAdapter adapter;
  //private OWLModel kb;


  public LexicalContextSetter(int index, Context origContext, String query) {
    adapter = new FormalContextAdapter();

    switch(index){
      case 1:
        this.addQueryToContextNameOption(origContext, query);
        break;
      case 2:
        this.addQueryToContextIdOption(origContext, query);
        break;
      case 3:
        this.addQueryToContextIdOptionBigram(origContext, query);
        break;
      default:
        this.addQueryToContextNameOption(origContext, query);
        break;
    }
  }

  private void addQueryToContextIdOptionBigram(Context context, String query){
    Collection queryWords = this.getIndividualWordsBigram(query);
    Collection origAttrs = this.getOrigAttrs(context);
    Collection intentWords = this.getIntentWords(origAttrs, queryWords);
    int objCount = context.getObjectCount();
    int attrCount = context.getAttributeCount();

    for(int i = 0; i < objCount; i++){
      ContextEntity objEntity = context.getObject(i);
      String objName = objEntity.getName();
      adapter.addFormalObject(objName);

      for(int j = 0; j < attrCount; j++){
        ContextEntity attrEntity = context.getAttribute(j);
        String attrName = attrEntity.getName();
        adapter.addFormalAttribute(attrName);
        if(context.getRelationAt(i,j)){
          adapter.setRelation(objName, attrName);
        }
      }
    }

    String queryName = "Query";
    adapter.addFormalObject(queryName);
    Iterator it = intentWords.iterator();
    while(it.hasNext()){
      String word = (String) it.next();
      if(origAttrs.contains(word)){
        adapter.addFormalAttribute(word);
        adapter.setRelation(queryName, word);
      }
    }
  }

  private void addQueryToContextIdOption(Context context, String query){
    Collection queryWords = this.getIndividualWords(query);
    Collection origAttrs = this.getOrigAttrs(context);
    Collection intentWords = this.getIntentWords(origAttrs, queryWords);
    int objCount = context.getObjectCount();
    int attrCount = context.getAttributeCount();

    for(int i = 0; i < objCount; i++){
      ContextEntity objEntity = context.getObject(i);
      String objName = objEntity.getName();
      adapter.addFormalObject(objName);

      for(int j = 0; j < attrCount; j++){
        ContextEntity attrEntity = context.getAttribute(j);
        String attrName = attrEntity.getName();
        adapter.addFormalAttribute(attrName);
        if(context.getRelationAt(i,j)){
          adapter.setRelation(objName, attrName);
        }
      }
    }

    String queryName = "Query";
    adapter.addFormalObject(queryName);
    Iterator it = intentWords.iterator();
    while(it.hasNext()){
      String word = (String) it.next();
      if(origAttrs.contains(word)){
        adapter.addFormalAttribute(word);
        adapter.setRelation(queryName, word);
      }
    }
  }

  private void addQueryToContextNameOption(Context context, String query){
    Collection queryWords = this.getIndividualWords(query);
    Collection origAttrs = this.getOrigAttrs(context);
    Collection intentWords = this.getIntentWords(origAttrs, queryWords);
    int objCount = context.getObjectCount();
    int attrCount = context.getAttributeCount();

    for(int i = 0; i < objCount; i++){
      ContextEntity objEntity = context.getObject(i);
      String objName = objEntity.getName();
      adapter.addFormalObject(objName);

      for(int j = 0; j < attrCount; j++){
        ContextEntity attrEntity = context.getAttribute(j);
        String attrName = attrEntity.getName();
        adapter.addFormalAttribute(attrName);
        if(context.getRelationAt(i,j)){
          adapter.setRelation(objName, attrName);
        }
      }
    }

    String queryName = "Query";
    adapter.addFormalObject(queryName);
    Iterator it = intentWords.iterator();
    while(it.hasNext()){
      String word = (String) it.next();
      if(origAttrs.contains(word)){
        adapter.addFormalAttribute(word);
        adapter.setRelation(queryName, word);
      }
    }

  }

  private Collection getOrigAttrs(Context formalcontext){
    Collection origAttrs = new ArrayList();
    int attrCount = formalcontext.getAttributeCount();

    for(int i = 0; i < attrCount; i++){
      ContextEntity attrEntity = formalcontext.getAttribute(i);
      origAttrs.add(attrEntity.getName());
    }

    return origAttrs;
  }

  private Collection getIntentWords(Collection all, Collection query){
    Collection ret = new ArrayList();
    Iterator it = query.iterator();
    while(it.hasNext()){
      String word = (String) it.next();
      if(all.contains(word)){
        ret.add(word);
      }
    }

    return ret;
  }

  private Collection getIndividualWords(String expression) {
    Collection ret = new ArrayList();

    expression = expression.replaceAll("\\(", "");
    expression = expression.replaceAll("\\)", "");
    expression = expression.replaceAll("\\,", "");
    expression = this.replaceNumber(expression);

    String[] words = expression.split(" ");
    for (int i = 0; i < words.length; i++) {
      String word = words[i];
      if (!word.equals("-")) {

        if (word.indexOf("-") >= 0) {

          //add a compound word
          if(!ret.contains(word.toLowerCase())){
            ret.add(word.toLowerCase());
          }

          //get individual words for a compound word
          String[] wordpair = word.split("-");
          for (int j = 0; j < wordpair.length; j++) {
            if (!ret.contains(wordpair[j].toLowerCase())) {
              ret.add(wordpair[j].toLowerCase());
            }
          }
        }
        else {
          if (!ret.contains(word.toLowerCase())) {
            ret.add(word.toLowerCase());
          }
        }
      }
    }


    return ret;
  }

  private String replaceNumber(String expression){
    String ret = expression;
    ret = ret.replaceAll("1", "I");
    ret = ret.replaceAll("2", "II");
    ret = ret.replaceAll("3", "III");
    ret = ret.replaceAll("4", "IV");
    ret = ret.replaceAll("5", "V");
    ret = ret.replaceAll("6", "VI");

    return ret;
  }

  private Collection getIndividualWordsBigram(String expression) {
    Collection ret = new ArrayList();

    Vector vecWords = new Vector();

    expression = expression.replaceAll("\\(", "");
    expression = expression.replaceAll("\\)", "");
    expression = expression.replaceAll("\\,", "");
    expression = this.replaceNumber(expression);

    String[] words = expression.split(" ");
    for (int i = 0; i < words.length; i++) {
      String word = words[i];
      if (!word.equals("-")) {

        vecWords.add(word.toLowerCase());
/*
        if (word.indexOf("-") >= 0) {

          //add a compound word
          if(!ret.contains(word.toLowerCase())){
            ret.add(word.toLowerCase());
          }

          //get individual words for a compound word
          String[] wordpair = word.split("-");
          for (int j = 0; j < wordpair.length; j++) {
            if (!ret.contains(wordpair[j].toLowerCase())) {
              ret.add(wordpair[j].toLowerCase());
            }
          }
        }
        else {
          if (!ret.contains(word.toLowerCase())) {
            ret.add(word.toLowerCase());
          }
        }
*/
      }
    }

    //getting bigram
    if(vecWords.size() > 1){
      for (int ii = 1; ii < vecWords.size(); ii++) {
         String bigram = (String) vecWords.elementAt(ii-1) + " " +
             (String) vecWords.elementAt(ii);
         ret.add(bigram);
      }
    }

    return ret;
  }


  public FormalContextAdapter getContextAdapter() {
    return this.adapter;
  }

}
