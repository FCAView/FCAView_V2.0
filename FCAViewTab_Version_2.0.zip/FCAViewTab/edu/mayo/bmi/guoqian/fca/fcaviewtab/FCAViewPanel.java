package edu.mayo.bmi.guoqian.fca.fcaviewtab;

/**
 * <p>ƒ^ƒCƒgƒ‹: FCAView Tab</p>
 * <p>�à–¾: Context-based ontolgoy building using formal concept analysis</p>
 * <p>’˜�ìŒ : Copyright (c) 2005</p>
 * <p>‰ïŽÐ–¼: Department of Medical Informatics, Hokkaido University Graudate School of Medicine</p>
 * @author Guoqian Jiang
 * @version 1.0
 */

import java.util.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;

//import Protege-2000 API
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.widget.*;

import conexp.core.*;
import conexp.frontend.*;
import conexp.frontend.latticeeditor.*;
import conexp.frontend.latticeeditor.queries.*;


//import edu.mayo.bmi.guoqian.fca.owlfcaviewtab.*;
import edu.mayo.bmi.guoqian.fca.sct.*;

public class FCAViewPanel
    extends JPanel implements ActionListener, TreeSelectionListener, ItemListener {
  private KnowledgeBase kb;

  private JButton btnShowContext;

  //private JPanel contextPanel;
  private JPanel contextPanel;
  private JScrollPane jsPane;

  // private FormalContextAdapter adapter;
  private FormalContextSetter setter;

//  private JPanel instanceListPanel;
  private JSplitPane mainPane;

//  private DirectInstancesList instanceList;
  private InstanceClsesPanel clsesPanel;

  private Collection instances; //From
  private Collection toInstances;
   private String[] selectedAttrs;

  private int typeIndex;
  private FormalAttributesSelectionPane attrSelection;
  private FormalAttributeTypeSelectionPane typeSelection;
  private FormalAttributesFinder finder;
  private FormalLatticeComponentPanel latticePanel;

  private String pointedInstance = "002";

  public FCAViewPanel(KnowledgeBase kb) {
    this.kb = kb;
    this.initUI();
  }

  private void initUI() {

    //left panel
    JPanel leftPanel = new JPanel(new BorderLayout());

    //class view panel
    clsesPanel = new InstanceClsesPanel(kb.getProject());
    clsesPanel.setAutoscrolls(true);
    leftPanel.add(clsesPanel, BorderLayout.CENTER);

    //show context button
    btnShowContext = new JButton("Show Context...");
    btnShowContext.addActionListener(this);

    JPanel leftBottomPanel = new JPanel(new GridLayout(1, 1));
    leftBottomPanel.add(btnShowContext);
    leftPanel.add(leftBottomPanel, BorderLayout.SOUTH);

    //right panel
    JPanel rightpanel = new JPanel();
    rightpanel.setLayout(new BorderLayout());

    //show context table and lattice
    contextPanel = new JPanel();
    jsPane = new JScrollPane();
    jsPane.getViewport().add(contextPanel, null);
    rightpanel.add(jsPane, BorderLayout.CENTER);

    //main pane to show left and right panel
    mainPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
                              true,
                              leftPanel,
                              rightpanel);
    mainPane.setOneTouchExpandable(true);
    this.setLayout(new BorderLayout());
    this.add(mainPane, BorderLayout.CENTER);
  }

  public void actionPerformed(ActionEvent e) {
    Object s = e.getSource();

    if (s == btnShowContext) {
      this.showContext_actionPerformed();
    }

  }

  private Context getContext() {
    setter = new FormalContextSetter(kb,
                                     instances,
                                     selectedAttrs,
                                     typeIndex,
                                     pointedInstance);
    FormalContextAdapter adapter = setter.getContextAdapter();
    return adapter.getContext();
  }

  private String getSelectionText() {
    String text = null;
    clsesPanel.setFocusable(true);
    Collection texts = clsesPanel.getSelection();
    Iterator it = texts.iterator();
    while (it.hasNext()) {
      Cls cls = (Cls) it.next();
      text = cls.getName();
      break;
    }
    return text;
  }

  private void showAttributes_actionPerformed(String clsName) {

    showTypeSelectionPane();
    typeIndex = typeSelection.getTypeIndex();

    if (typeIndex == 0) {
      booleanType_actionPerformed(clsName);
    }
    else if (typeIndex == 1) {
      multipleType_actionPerformed(clsName);
    }else if(typeIndex == 2){
      booleanTypeSubclass_actionPerformed(clsName);
    }else if(typeIndex == 3){
      multipleTypeSubclass_actionPerformed(clsName);
    }else if(typeIndex == 6){
      CGtoFCA_actionPerformed(clsName);
    }
  }

  private void showTypeSelectionPane(){

    typeSelection = new FormalAttributeTypeSelectionPane();

    Dimension dlgSize = typeSelection.getPreferredSize();
    Dimension frmSize = getSize();
    Point loc = getLocation();
    typeSelection.setLocation( (frmSize.width - dlgSize.width) / 2 + loc.x,
                              (frmSize.height - dlgSize.height) / 2 + loc.y);
    typeSelection.setModal(true);
    typeSelection.pack();
    typeSelection.show();

  }

  private void showAttrSelectionPane(String[] attrs){
    attrSelection =
        new FormalAttributesSelectionPane(attrs);

    Dimension dlgSize = attrSelection.getPreferredSize();
    Dimension frmSize = getSize();
    Point loc = getLocation();
    attrSelection.setLocation( (frmSize.width - dlgSize.width) / 2 + loc.x,
                              (frmSize.height - dlgSize.height) / 2 + loc.y);
    attrSelection.setModal(true);
    attrSelection.pack();
    attrSelection.show();
  }

  //limiting to boolean type of slots
  private void booleanType_actionPerformed(String clsName) {
    finder = new FormalAttributesFinder(kb, clsName);
    String[] listAttributes = finder.getPossibleFormatAttributesForBoolean();
    instances = finder.getFormalObjects();
    showAttrSelectionPane(listAttributes);
    selectedAttrs = attrSelection.getSelectedItems();
  }

  //limiting to multiple type of slots
  private void multipleType_actionPerformed(String clsName) {
    finder = new FormalAttributesFinder(kb, clsName);
    String[] listAttributes = finder.getPossibleFormalAttributesForMultiple();
    instances = finder.getFormalObjects();

    showAttrSelectionPane(listAttributes);
    selectedAttrs = attrSelection.getSelectedItems();

  }

  //limiting to boolean type of slots
  private void booleanTypeSubclass_actionPerformed(String clsName) {
    finder = new FormalAttributesFinder(kb, clsName);
    String[] listAttributes = finder.getPossibleFormatAttributesForBoolean();
    instances = finder.getSubClses();
    showAttrSelectionPane(listAttributes);
    selectedAttrs = attrSelection.getSelectedItems();
    pointedInstance = "002";
  }

  //limiting to multiple type of slots
  private void multipleTypeSubclass_actionPerformed(String clsName) {
    finder = new FormalAttributesFinder(kb, clsName);
    String[] listAttributes = finder.getPossibleFormalAttributesForMultiple();
    instances = finder.getSubClses();

    showAttrSelectionPane(listAttributes);
    selectedAttrs = attrSelection.getSelectedItems();
    pointedInstance = "002";

  }

  //CGtoFCA
  private void CGtoFCA_actionPerformed(String clsName) {
    finder = new FormalAttributesFinder(kb, clsName);
    String[] listAttributes = finder.getPossibleFormalAttributesForCG();
  
    instances = finder.getCGObjects();
        
    // showAttrSelectionPane(listAttributes);
    selectedAttrs = listAttributes;// disable selectionattrSelection.getSelectedItems();
    pointedInstance = "002";

  }

  //starting to show context
  private void showContext_actionPerformed() {

    String clsName = this.getSelectionText();
    this.showAttributes_actionPerformed(clsName);
    Context formalcontext = this.getContext();
    latticePanel = new FormalLatticeComponentPanel(formalcontext);

    //to form a concept tree
    //test(latticePanel);

    jsPane.getViewport().add(latticePanel, null);
    latticePanel.setVisible(true);
  }

/*
  private void test(FormalLatticeComponentPanel latticePanel) {
    ContextDocument doc = latticePanel.getContextDocument();
    doc.calculateLattice();
    Lattice lattice = doc.getLatticeComponent().getLattice();

        ConceptTreePane treePane = new ConceptTreePane(lattice, kb);
        Dimension dlgSize = attrSelection.getPreferredSize();
        Dimension frmSize = getSize();
        Point loc = getLocation();
        treePane.setLocation( (frmSize.width - dlgSize.width) / 2 + loc.x,
     (frmSize.height - dlgSize.height) / 2 + loc.y);
        //treePane.setModal(true);
        treePane.pack();
        treePane.show();

  }
*/
 

@Override
public void itemStateChanged(ItemEvent arg0) {
	// TODO Auto-generated method stub
	
}

@Override
public void valueChanged(TreeSelectionEvent arg0) {
	// TODO Auto-generated method stub
	
}
}
