package edu.mayo.bmi.guoqian.fca.fcaviewtab;

/**
 * <p>ƒ^ƒCƒgƒ‹: FCAView Tab</p>
 * <p>�à–¾: Context-based ontolgoy building using formal concept analysis</p>
 * <p>’˜�ìŒ : Copyright (c) 2005</p>
 * <p>‰ïŽÐ–¼: Department of Medical Informatics, Hokkaido University Graudate School of Medicine</p>
 * @author Guoqian Jiang
 * @version 1.0
 */

import java.io.*;
import java.util.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


//import Protege-2000 API
import edu.stanford.smi.protege.model.Frame;
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.util.*;
import edu.stanford.smi.protege.ui.*;

import conexp.core.*;

public class FormalAttributesFinder {

	private KnowledgeBase kb;
	private String clsName;

	private Collection formalObjects;
	private Collection allTemplateSlots;
	private Collection allCGIntances; 

	public FormalAttributesFinder(KnowledgeBase kb, String clsName) {
		this.kb = kb;
		this.clsName = clsName;
		formalObjects = getFormalObjects();
		allTemplateSlots = getAllTemplateSlots();     
		allCGIntances = getAllCGInstances();
	}

	private Vector getSlotsWithBooleanType(){
		Vector results = new Vector();
		Iterator it = allTemplateSlots.iterator();
		while(it.hasNext()){
			Slot slot = (Slot) it.next();
			if(slot.getValueType() == ValueType.BOOLEAN){
				results.add(slot.getBrowserText());
			}
		}
		return results;
	}

	private Vector getSlotsWithMultipleInstanceType(){
		Vector results = new Vector();
		Iterator it = allTemplateSlots.iterator();
		while(it.hasNext()){
			Slot slot = (Slot) it.next();
			if(slot.getValueType() == ValueType.INSTANCE &&
					slot.getAllowsMultipleValues()){
				results.add(slot.getBrowserText());
			}
		}
		return results;
	}

	private Object getSlotValue(Instance inst,String slot_name)
	{
		Object value = null;
		Collection<Slot> slots=inst.getOwnSlots();
		Iterator it2 = slots.iterator();
		while(it2.hasNext()){
			Slot slot = (Slot) it2.next();
			if (slot.getName()==slot_name){
				value= inst.getOwnSlotValue(slot);
			}
		}
		return value;
	}

	private Vector getCGAttributes(){
		Vector results = new Vector();
		String ConceptFrom=null,ConceptTo = null,Relation=null;
		Collection objects = getCGConceptToRelationClses();
		Collection objects2 = getCGRelationToConceptClses();
		Iterator it = objects.iterator();
		while (it.hasNext()) {
			//we have to build the tripple e.g. Transaction part cashpayment
			Instance inst = (Instance) it.next();
			Instance FromInst= (Instance) getSlotValue(inst,":FROM");
			if (FromInst!=null) ConceptFrom = (String) getSlotValue(FromInst,"Preferred_name");
			Instance ToInst= (Instance) getSlotValue(inst,":TO");
			if (ToInst!=null) Relation = (String) getSlotValue(ToInst,"Preferred_name");

			//now find the other concept
			Iterator it2 = objects2.iterator();
			while (it2.hasNext()) {
				//we have to build the tripple e.g. Transaction part cashpayment
				Instance inst2 = (Instance) it2.next();
				Instance FromInst2= (Instance) getSlotValue(inst2,":FROM");
				if (FromInst2!=null&&FromInst2.equals(ToInst)) {
					Instance ToRel= (Instance) getSlotValue(inst2,":TO");
					if (ToRel!=null) ConceptTo = (String) getSlotValue(ToRel,"Preferred_name");
					break;
				}
			}

			//ignore default concept
			if (ConceptFrom!="dummy_concept") {

				String FormalObject=ConceptFrom+" "+Relation +" "+ ConceptTo;// we don't need this for the tripple +" "+ConceptTo;
				results.add(FormalObject);
				//			if (instance.getBrowserText().equals(inskey)) {
			}
		}
		return results;
	}

	Vector getCGObjects(){
		Vector results = new Vector();
		Iterator it = allCGIntances.iterator();
		while(it.hasNext()){
			Instance ins = (Instance) it.next();
			Collection<Slot> slots=ins.getOwnSlots();
			Iterator it2 = slots.iterator();
			while(it2.hasNext()){
				Slot slot = (Slot) it2.next();
				if (slot.getName()=="Preferred_name"){
					String slot_value=(String) ins.getOwnSlotValue(slot);
					if (!slot_value.isEmpty()&&!slot_value.equals("dummy_concept")){
						results.add(slot_value);
					}
				}

			}
		}
		return results;
	}


	public String[] getPossibleFormatAttributesForBoolean(){
		Vector slots = this.getSlotsWithBooleanType();
		String[] results = new String[slots.size()];
		slots.copyInto(results);
		return results;
	}

	public String[] getPossibleFormalAttributesForMultiple(){
		Vector slots = this.getSlotsWithMultipleInstanceType();
		String[] results = new String[slots.size()];
		slots.copyInto(results);
		return results;
	}

	public String[] getPossibleFormalAttributesForCG(){

		Vector slots = this.getCGAttributes();
		String[] results = new String[slots.size()];
		slots.copyInto(results);
		return results;
	}

	public Collection getFormalObjects(){
		Cls cls = kb.getCls(clsName);
		Collection instances = null;
		if (cls!=null)
			instances = cls.getDirectInstances();
		return instances;
	}

	public Collection getSubClses(){
		Cls cls = kb.getCls(clsName);
		Collection clses = cls.getDirectSubclasses();
		return clses;
	}

	public Collection getCGConceptToRelationClses(){
		Cls cls = kb.getCls("concept to relation");
		Collection insts = cls.getDirectInstances();
		return insts;
	}

	public Collection getCGRelationToConceptClses(){
		Cls cls = kb.getCls("relation to concept");
		Collection insts = cls.getDirectInstances();
		return insts;
	}

	private Collection getAllTemplateSlots(){
		Cls cls = kb.getCls(clsName);
		Collection templateSlots = cls.getTemplateSlots();
		return templateSlots;
	}

	private Collection getAllCGInstances(){
		Cls cls = kb.getCls("T");
		if (cls!=null){
			Collection instances = cls.getInstances();
			return instances;
		}
		else
			return null;
	}

}















