package edu.mayo.bmi.guoqian.fca.fcaviewtab;

/**
 * <p>�^�C�g��: FCAView Tab</p>
 * <p>����: Context-based ontolgoy building using formal concept analysis</p>
 * <p>���쌠: Copyright (c) 2005</p>
 * <p>��Ж�: Department of Medical Informatics, Hokkaido University Graudate School of Medicine</p>
 * @author Guoqian Jiang
 * @version 1.0
 */

import conexp.frontend.latticeeditor.*;
import conexp.util.gui.paramseditor.*;

import edu.mayo.bmi.guoqian.fca.owlfcaviewtab.*;
import edu.mayo.bmi.guoqian.fca.sct.*;

public class LatticeDrawingAdapter extends LatticeDrawing{

  public LatticeDrawingAdapter() {
    super();
  }

  public ParamInfo[] getParams(){
    return this.getLabelingStrategiesParams();
  }

}
