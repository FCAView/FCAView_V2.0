package edu.mayo.bmi.guoqian.fca.fcaviewtab;

/**
 * <p>ƒ^ƒCƒgƒ‹: FCAView Tab</p>
 * <p>�à–¾: Context-based ontolgoy building using formal concept analysis</p>
 * <p>’˜�ìŒ : Copyright (c) 2005</p>
 * <p>‰ïŽÐ–¼: Department of Medical Informatics, Hokkaido University Graudate School of Medicine</p>
 * @author Guoqian Jiang
 * @version 1.0
 */

import java.util.*;

//import Protege-2000 API
import edu.stanford.smi.protege.model.*;

public class FormalContextSetter {

	private FormalContextAdapter adapter;
	private KnowledgeBase kb;

	public FormalContextSetter(KnowledgeBase kb,
			Collection objects,
			/*Collection objects2,*/
			String[] attributes,
			int typeIndex,
			String insstr) {
		this.kb = kb;
		adapter = new FormalContextAdapter();
		if (typeIndex == 0) {
			this.setContextForBoolean(objects, attributes);
		}
		else if (typeIndex == 1) {
			this.setContextForMultiple(objects, attributes);
		}else if (typeIndex == 2){
			this.setContextForSubclassBoolean(objects, attributes, insstr);
		}else if (typeIndex == 3){
			this.setContextForSubClassMultiple(objects, attributes, insstr);
		}else if (typeIndex == 6){
			this.setContextForCGtoFCA(objects, attributes, insstr);
		}
	}

	private void setContextForBoolean(Collection objects, String[] attributes) {
		Iterator it = objects.iterator();
		while (it.hasNext()) {
			Instance instance = (Instance) it.next();
			adapter.addFormalObject(instance);
			for (int i = 0; i < attributes.length; i++) {
				Slot slot = kb.getSlot(attributes[i]);
				adapter.addFormalAttribute(slot);
				Collection values = instance.getDirectOwnSlotValues(slot);
				if (!values.isEmpty()) {
					Boolean b = (Boolean) instance.getDirectOwnSlotValue(slot);
					if (b.booleanValue()) {
						adapter.setRelation(instance, slot);
					}
				}
			}
		}
	}

	private void setContextForMultiple(Collection objects, String[] attributes) {
		Iterator it = objects.iterator();
		while (it.hasNext()) {
			Instance instance = (Instance) it.next();
			adapter.addFormalObject(instance);
			for (int i = 0; i < attributes.length; i++) {
				Slot slot = kb.getSlot(attributes[i]);
				Collection values = instance.getDirectOwnSlotValues(slot);
				if (!values.isEmpty()) {
					Iterator itv = values.iterator();
					while (itv.hasNext()) {
						Instance slotIns = (Instance) itv.next();
						adapter.addFormalAttribute(slotIns);
						adapter.setRelation(instance, slotIns);
					}
				}
			}
		}

	}

	private void setContextForSubclassBoolean(Collection objects,
			String[] attributes,
			String inskey) {
		Iterator it = objects.iterator();
		while (it.hasNext()) {
			Cls cls = (Cls) it.next();
			adapter.addFormalObject(cls);
			Collection instances = cls.getDirectInstances();
			Iterator it1 = instances.iterator();
			while (it1.hasNext()) {
				Instance instance = (Instance) it1.next();
				if (instance.getBrowserText().equals(inskey)) {
					for (int i = 0; i < attributes.length; i++) {
						Slot slot = kb.getSlot(attributes[i]);
						adapter.addFormalAttribute(slot);
						Collection values = instance.getDirectOwnSlotValues(slot);
						if (!values.isEmpty()) {
							Boolean b = (Boolean) instance.getDirectOwnSlotValue(slot);
							if (b.booleanValue()) {
								adapter.setRelation(cls, slot);
							}
						}
					}
				}
			}
		}
	}

	private void setContextForSubClassMultiple(Collection objects,
			String[] attributes,
			String inskey) {
		Iterator it = objects.iterator();
		while (it.hasNext()) {
			Cls cls = (Cls) it.next();
			adapter.addFormalObject(cls);
			Collection instances = cls.getDirectInstances();
			Iterator it1 = instances.iterator();
			while (it1.hasNext()) {
				Instance instance = (Instance) it1.next();
				if (instance.getBrowserText().equals(inskey)) {
					for (int i = 0; i < attributes.length; i++) {
						Slot slot = kb.getSlot(attributes[i]);
						adapter.addFormalAttribute(slot);
						Collection values = instance.getDirectOwnSlotValues(slot);
						if (!values.isEmpty()) {
							Iterator itv = values.iterator();
							while (itv.hasNext()) {
								Instance slotIns = (Instance) itv.next();
								adapter.addFormalAttribute(slotIns);
								adapter.setRelation(cls, slotIns);
							}
						}
					}
				}
			}
		}
	}

	private Object getSlotValue(Instance inst,String slot_name)
	{
		Object value = null;
		Collection<Slot> slots=inst.getOwnSlots();
		Iterator it2 = slots.iterator();
		while(it2.hasNext()){
			Slot slot = (Slot) it2.next();
			if (slot.getName()==slot_name){
				value= inst.getOwnSlotValue(slot);
			}
		}
		return value;
	}

	private void setContextForCGtoFCA(Collection objects,
			String[] attributes,
			String inskey) {
		String ConceptFrom=null,ConceptTo = null,Relation=null;
		Iterator it = objects.iterator();
		while (it.hasNext()) {
			Object inst = it.next();
			adapter.addFormalObject(inst.toString());
			for (int i = 0; i < attributes.length; i++) {
				
				ConceptTo=attributes[i].substring(attributes[i].lastIndexOf(" ")+1);
				if (inst.equals(ConceptTo)){
					//Slot slot = kb.getSlot(attributes[i]);
					int x = attributes[i].indexOf(' ');
					String Attribute = attributes[i].substring(0, attributes[i].lastIndexOf(" "));
					adapter.addFormalAttribute(Attribute);
					adapter.setRelation(inst.toString(), Attribute);
				}
			}
		}


		/*		Iterator it = objects.iterator();
		while (it.hasNext()) {
			//we have to build the tripple e.g. Transaction part cashpayment
			Instance inst = (Instance) it.next();
			Instance FromInst= (Instance) getSlotValue(inst,":FROM");
			if (FromInst!=null) ConceptFrom = (String) getSlotValue(FromInst,"Preferred_name");
			Instance ToInst= (Instance) getSlotValue(inst,":TO");
			if (ToInst!=null) Relation = (String) getSlotValue(ToInst,"Preferred_name");

			//now find the other concept
			Iterator it2 = objects2.iterator();
			while (it2.hasNext()) {
				//we have to build the tripple e.g. Transaction part cashpayment
				Instance inst2 = (Instance) it2.next();
				Instance FromInst2= (Instance) getSlotValue(inst2,":FROM");
				if (FromInst2!=null&&FromInst2.equals(ToInst)) {
					Instance ToRel= (Instance) getSlotValue(inst2,":TO");
					if (ToRel!=null) ConceptTo = (String) getSlotValue(ToRel,"Preferred_name");
					break;
				}
			}

			//ignore default concept
			if (ConceptFrom!="dummy_concept") {

				String FormalObject=ConceptFrom+" "+Relation;// we don't need this for the tripple +" "+ConceptTo;
				adapter.addFormalObject(FormalObject);
				//			if (instance.getBrowserText().equals(inskey)) {
				//			if (From.equals(inskey)){
				for (int i = 0; i < attributes.length; i++) {
					if (attributes[i]==ConceptFrom){
					Slot slot = kb.getSlot(attributes[i]);
					adapter.addFormalAttribute(attributes[i]);
					adapter.setRelation(FormalObject, attributes[i]);
				}
				els 
					if (attributes[i]==ConceptTo){
						Slot slot = kb.getSlot(attributes[i]);
						adapter.addFormalAttribute(attributes[i]);
						adapter.setRelation(FormalObject, attributes[i]);
					}
				}
			}
		}*/
	}
	//	}


	public FormalContextAdapter getContextAdapter() {
		return this.adapter;
	}
}
