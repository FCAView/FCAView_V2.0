package edu.mayo.bmi.guoqian.fca.fcaviewtab;

/**
 * <p>�^�C�g��: FCAView Tab</p>
 * <p>����: Context-based ontolgoy building using formal concept analysis</p>
 * <p>���쌠: Copyright (c) 2005</p>
 * <p>��Ж�: Department of Medical Informatics, Hokkaido University Graudate School of Medicine</p>
 * @author Guoqian Jiang
 * @version 1.0
 */

import java.util.*;

//import Concept Explorer API
import conexp.core.*;

//import the Protege API
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protegex.owl.model.*;


public class FormalContextAdapter extends FormalContextInterface{

  private Context context;
  private Vector entities;
  private Map formalObjects;
  private Map formalAttributes;

  public FormalContextAdapter() {
    this.context = FCAEngineRegistry.makeContext(1,1);

    this.entities = new Vector();
    this.formalObjects = new HashMap();
    this.formalAttributes = new HashMap();

  }

  public void addFormalObject(String object){
    int o = formalObjects.size();
    if(!formalObjects.containsKey(object)){
      formalObjects.put(object, new Integer(o+1));
      ContextEntity entity = ContextEntity.createContextObject(object);
      entities.add(entity);
      context.addObject(entity);
    }

  }

  public void addFormalObject(Cls object){
    int o = formalObjects.size();
    if(!formalObjects.containsKey(object)){
      formalObjects.put(object, new Integer(o+1));
      String objname = object.getBrowserText();
      ContextEntity entity = ContextEntity.createContextObject(objname);
      entities.add(entity);
      context.addObject(entity);
    }

  }



  public void addFormalObject(OWLNamedClass object){
    int o = formalObjects.size();
    if(!formalObjects.containsKey(object)){
      formalObjects.put(object, new Integer(o+1));
      String objname = object.getBrowserText();
      ContextEntity entity = ContextEntity.createContextObject(objname);
      entities.add(entity);
      context.addObject(entity);
    }
  }

  public void addFormalObject(Instance object){
    int o = formalObjects.size();
    if(!formalObjects.containsKey(object)){
      formalObjects.put(object, new Integer(o+1));
      String objname = object.getBrowserText();
      ContextEntity entity = ContextEntity.createContextObject(objname);
      entities.add(entity);
      context.addObject(entity);
    }
  }

  public void addFormalAttribute(OWLNamedClass attribute){
   int a = formalAttributes.size();
   if(!formalAttributes.containsKey(attribute)){
     formalAttributes.put(attribute, new Integer(a+1));
     String attname = attribute.getBrowserText();
     ContextEntity entity = ContextEntity.createContextAttribute(attname);
     entities.add(entity);
     context.addAttribute(entity);
   }
 }

 public void addFormalAttribute(String attribute){
  int a = formalAttributes.size();
  if(!formalAttributes.containsKey(attribute)){
    formalAttributes.put(attribute, new Integer(a+1));
    String attname = attribute;
    ContextEntity entity = ContextEntity.createContextAttribute(attname);
    entities.add(entity);
    context.addAttribute(entity);
  }
 }

  public void addFormalAttribute(Instance attribute){
   int a = formalAttributes.size();
   if(!formalAttributes.containsKey(attribute)){
     formalAttributes.put(attribute, new Integer(a+1));
     String attname = attribute.getBrowserText();
     ContextEntity entity = ContextEntity.createContextAttribute(attname);
     entities.add(entity);
     context.addAttribute(entity);
   }
 }

  public void addFormalAttribute(Slot attribute){
   int a = formalAttributes.size();
   if(!formalAttributes.containsKey(attribute)){
     formalAttributes.put(attribute, new Integer(a+1));
     String attname = attribute.getBrowserText();
     ContextEntity entity = ContextEntity.createContextAttribute(attname);
     entities.add(entity);
     context.addAttribute(entity);
   }
 }

  /**
   * Add the instance to objects
   */
  private void addObjectIfNotExisted(Instance object) {
    int o = formalObjects.size();
    if(!formalObjects.containsKey(object))
      formalObjects.put(object, new Integer(o+1));
  }

  /**
   * Add the instance to attributes
   */
  private void addAttributeIfNotExisted(Slot attribute) {
    int a = formalAttributes.size();
    if(!formalAttributes.containsKey(attribute))
      formalAttributes.put(attribute, new Integer(a+1));
  }

  public void setRelation(Instance object, Instance attribute){
    Integer o = (Integer) formalObjects.get(object);
    Integer a = (Integer) formalAttributes.get(attribute);
    context.setRelationAt(o.intValue(), a.intValue(), true);
  }

  public void setRelation(OWLNamedClass object, OWLNamedClass attribute){
    Integer o = (Integer) formalObjects.get(object);
    Integer a = (Integer) formalAttributes.get(attribute);
    context.setRelationAt(o.intValue(), a.intValue(), true);
  }

  public void setRelation(OWLNamedClass object, String attribute){
    Integer o = (Integer) formalObjects.get(object);
    Integer a = (Integer) formalAttributes.get(attribute);
    context.setRelationAt(o.intValue(), a.intValue(), true);
  }

  public void setRelation(Instance object, Slot attribute){
    Integer o = (Integer) formalObjects.get(object);
    Integer a = (Integer) formalAttributes.get(attribute);
    context.setRelationAt(o.intValue(), a.intValue(), true);
  }

  public void setRelation(String object, String attribute){
    Integer o = (Integer) formalObjects.get(object);
    Integer a = (Integer) formalAttributes.get(attribute);
    context.setRelationAt(o.intValue(), a.intValue(), true);
  }

  public Lattice getLattice(){
    return FCAEngineRegistry.buildLattice(context);
  }

  public ConceptsCollection getConceptsCollection(){
    return FCAEngineRegistry.buildConceptSet(context);

  }

  public Context getContext(){
    context.removeAttribute(0);
    context.removeObject(0);
    return this.context;
  }

}
