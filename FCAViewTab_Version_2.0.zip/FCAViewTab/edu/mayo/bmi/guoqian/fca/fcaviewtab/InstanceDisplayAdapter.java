package edu.mayo.bmi.guoqian.fca.fcaviewtab;

/**
 * <p>�^�C�g��: FCAView Tab</p>
 *
 * <p>����: Context-based ontolgoy building using formal concept analysis</p>
 *
 * <p>���쌠: Copyright (c) 2005</p>
 *
 * <p>��Ж�: Department of Medical Informatics, Hokkaido University Graudate
 * School of Medicine</p>
 *
 * @author Guoqian Jiang
 * @version 1.0
 */

import java.util.*;
import javax.swing.*;
import edu.mayo.bmi.guoqian.fca.owlfcaviewtab.*;
import edu.mayo.bmi.guoqian.fca.sct.*;

//import Protege-2000 API
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.widget.*;
import edu.stanford.smi.protege.ui.*;


public class InstanceDisplayAdapter extends InstanceDisplay{

  private Instance instance;
  private KnowledgeBase kb;

  public InstanceDisplayAdapter(Instance instance, KnowledgeBase kb) {
    super(kb.getProject());
    this.instance = instance;
    this.kb = kb;
  }

  public JComponent getForm(){
    Collection col = new ArrayList();
    ClsWidget clsWidget = kb.getProject().createRuntimeClsWidget(instance);
    return super.createWidgetContainer(col);

  }
}
