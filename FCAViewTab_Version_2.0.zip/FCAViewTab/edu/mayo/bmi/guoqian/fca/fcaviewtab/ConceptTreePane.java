package edu.mayo.bmi.guoqian.fca.fcaviewtab;

/**
 * <p>�^�C�g��: FCAView Tab</p>
 *
 * <p>����: Context-based ontolgoy building using formal concept analysis</p>
 *
 * <p>���쌠: Copyright (c) 2005</p>
 *
 * <p>��Ж�: Department of Medical Informatics, Hokkaido University Graudate
 * School of Medicine</p>
 *
 * @author Guoqian Jiang
 * @version 1.0
 */

import java.util.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.event.*;

import conexp.core.*;

//import Protege-2000 API
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.widget.*;
import edu.stanford.smi.protege.ui.*;

public class ConceptTreePane
    extends JFrame implements ActionListener {

  private JLabel label;
  private JTree conceptTree;
  private SelectInstanceFromCollectionPanel insPanel;
  private InstanceDisplay instanceDisplay;
  private JScrollPane scrollPane2;
  private JScrollPane scrollPane3;
  private JTextArea textArea;
  private JButton btnOK;

  private JSplitPane jsplit1;
  private JSplitPane jsplit2;

  private Lattice lattice;
  private KnowledgeBase kb;

  private static String summary = "PatientDischargeSummary";

  public ConceptTreePane(Lattice lattice, KnowledgeBase kb) {

    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      this.lattice = lattice;
      this.kb = kb;
      initUI();
      this.setSize(600, 1000);
      this.setResizable(true);
      this.setTitle("Concept Tree");
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  private void initUI() throws Exception {
    this.getContentPane().setLayout(new BorderLayout());


    label = new JLabel("Concept Tree: ");

    JScrollPane scrollPane1 = new JScrollPane();
    TreeModel treeModel = new LatticeTreeModel(lattice);

    conceptTree = new JTree(treeModel);
    scrollPane1.getViewport().add(conceptTree);
    scrollPane1.setPreferredSize(new Dimension(200,600));


     scrollPane2 = new JScrollPane();
     scrollPane2.setPreferredSize(new Dimension(200,600));
     scrollPane3 = new JScrollPane();
     scrollPane3.setPreferredSize(new Dimension(300,600));

    textArea = new JTextArea();
    textArea.setEditable(false);
    scrollPane3.getViewport().add(textArea);
    jsplit2 = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, scrollPane2, scrollPane3);
    jsplit2.setOneTouchExpandable(true);



    conceptTree.addTreeSelectionListener(new
                                         TreeSelectionListener() {
      public void valueChanged(TreeSelectionEvent event) {
        TreePath path = conceptTree.getSelectionPath();
        if (path == null) {
          return;
        }

        LatticeElementAdapter lea =
            (LatticeElementAdapter) path.getLastPathComponent();
        textArea.setText(lea.getAttributes());
        Collection inses = lea.getObjectsCollection();
        insPanel = new SelectInstanceFromCollectionPanel(inses, 0);
        scrollPane2.getViewport().add(insPanel);

        //Instance ins = insPanel.getSelection();
        //instanceDisplay = new InstanceDisplay(kb.getProject());
        //instanceDisplay.setInstance(ins);
        //scrollPane3.getViewport().add(instanceDisplay);
      }

    });



    conceptTree.getSelectionModel().setSelectionMode(
        TreeSelectionModel.SINGLE_TREE_SELECTION);

    btnOK = new JButton("OK...");
    btnOK.addActionListener(this);

    JPanel okPanel = new JPanel();
    okPanel.add(btnOK);

    //leftPanel
    JPanel leftPanel = new JPanel(new BorderLayout());
    leftPanel.add(label, BorderLayout.NORTH);
    leftPanel.add(scrollPane1, BorderLayout.CENTER);
    leftPanel.add(okPanel, BorderLayout.SOUTH);

    //
    JPanel rightPanel = new JPanel(new BorderLayout());
    rightPanel.add(jsplit2, BorderLayout.CENTER);


    jsplit1 = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPanel, rightPanel);
    jsplit1.setOneTouchExpandable(true);



    this.getContentPane().add(jsplit1, BorderLayout.CENTER);

  }

  //�E�B���h�E������ꂽ�Ƃ��ɏI������悤�ɃI�[�o�[���C�h
  protected void processWindowEvent(WindowEvent e) {
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      cancel();
    }
    super.processWindowEvent(e);
  }

  //�_�C�A���O�����
  void cancel() {
    dispose();
  }

  public void actionPerformed(ActionEvent e) {
    Object s = e.getSource();

    if (s == btnOK) {

      Instance selectedIns = insPanel.getSelection();
      ClsWidget clsWidget = kb.getProject().createRuntimeClsWidget(selectedIns);
      InstanceDisplayAdapter insDisplay = new InstanceDisplayAdapter(selectedIns, kb);
      JFrame frame = new JFrame(selectedIns.getBrowserText());
      frame.getContentPane().setLayout(new BorderLayout());
      JComponent form = insDisplay.getForm();
      JScrollPane scrollPane = new JScrollPane(form);
      frame.getContentPane().add(scrollPane, BorderLayout.CENTER);
      frame.pack();
      frame.show();

      //cancel();

    }

  }

  private Collection getAllObjects(Concept concept, Context cxt) {
    Collection result = new ArrayList();

    return null;
  }

  class LatticeTreeModel
      implements TreeModel {

    private Lattice lattice;
    private Context context;

    private Vector listeners;

    public LatticeTreeModel(Lattice lattice) {
      this.lattice = lattice;
      this.context = lattice.getContext();

      this.listeners = new Vector();
    }

    public Object getRoot() {
      LatticeElement top = lattice.getTop();
      LatticeElementAdapter topa = new LatticeElementAdapter(top, lattice);
      return topa;
    }

    public Object getChild(Object parent, int index) {
      LatticeElementCollection children = ( (LatticeElementAdapter) parent).
          getLatticeElement().getChildren();
      LatticeElement child = children.get(index);
      LatticeElementAdapter childa = new LatticeElementAdapter(child, lattice);

      return childa;
    }

    public int getChildCount(Object parent) {
      LatticeElementCollection children = ( (LatticeElementAdapter) parent).
          getLatticeElement().getChildren();
      int count = children.getSize();
      return count;
    }

    public int getIndexOfChild(Object parent, Object child) {
      int index = 0;
      LatticeElementCollection children = ( (LatticeElementAdapter) parent).
          getLatticeElement().getChildren();
      int count = children.getSize();
      for (int i = 0; i < count; i++) {
        LatticeElement element = children.get(i);
        LatticeElement childe = ( (LatticeElementAdapter) child).
            getLatticeElement();
        if (element.equals(childe)) {
          index = i;
        }
      }

      return index;
    }

    public boolean isLeaf(Object node) {
      boolean result = false;
      LatticeElementCollection children = ( (LatticeElementAdapter) node).
          getLatticeElement().getChildren();
      int count = children.getSize();
      if (count <= 1) {
        result = true;
      }

      return result;
    }

    public void addTreeModelListener(TreeModelListener l) {
      if (l != null && !listeners.contains(l)) {
        listeners.add(l);
      }
    }

    public void removeTreeModelListener(TreeModelListener l) {
      if (l != null) {
        listeners.remove(l);
      }
    }

    public void valueForPathChanged(TreePath path, Object newValue) {
      //do nothing
    }
  }

  class LatticeElementAdapter {
    private LatticeElement element;
    private Lattice lattice;
    public LatticeElementAdapter(LatticeElement element, Lattice lattice) {
      this.element = element;
      this.lattice = lattice;
    }

    public LatticeElement getLatticeElement() {
      return this.element;
    }

    public Lattice getLattice() {
      return this.getLattice();
    }

    public Collection getObjectsCollection() {
      Collection result = new ArrayList();
      Cls cls = kb.getCls(summary);
      Collection instances = cls.getInstances();
      int index = element.getIndex();
      Concept concept = lattice.conceptAt(index);
      //int nobj = concept.getObjCnt();
      //StringBuffer sb = new StringBuffer();
      Iterator it = concept.extentIterator(lattice.getContext());
      while (it.hasNext()) {
        ContextEntity entity = (ContextEntity) it.next();
        //result.add(entity.getName());
        Iterator it1 = instances.iterator();
        while (it1.hasNext()) {
          Instance ins = (Instance) it1.next();
          String inskey = ins.getBrowserText();
          if (inskey.equals(entity.getName())) {
            result.add(ins);
          }
        }
      }
      return result;
    }

    public String getObjects() {
      int index = element.getIndex();
      Concept concept = lattice.conceptAt(index);
      //int nobj = concept.getObjCnt();
      StringBuffer sb = new StringBuffer();
      Iterator it = concept.extentIterator(lattice.getContext());
      while (it.hasNext()) {
        ContextEntity entity = (ContextEntity) it.next();
        sb.append(entity.getName());
        sb.append("\n");
      }
      return sb.toString();
    }

    public String getAttributes() {
      int index = element.getIndex();
      Concept concept = lattice.conceptAt(index);
      //int nobj = concept.getObjCnt();
      StringBuffer sb = new StringBuffer();
      Iterator it = concept.intentIterator(lattice.getContext());
      while (it.hasNext()) {
        ContextEntity entity = (ContextEntity) it.next();
        sb.append(entity.getName());
        sb.append("\n");
      }
      return sb.toString();
    }

    public String toString() {
      int index = element.getIndex();
      Concept concept = lattice.conceptAt(index);
      int nattr = concept.getOwnAttrCnt();
      int nobj = concept.getOwnObjCnt();
      Iterator it1 = concept.ownAttribsIterator();
      StringBuffer sb = new StringBuffer();
      int na = 1;
      while (it1.hasNext()) {
        ContextEntity attr = (ContextEntity) it1.next();
        if (na == nattr) {
          sb.append(attr.getName());
          break;
        }
        sb.append(attr.getName());
        sb.append("|");
        na++;
      }
      sb.append("(");
      int num = concept.getObjCnt();
      sb.append(num);

      /*
             Iterator it2 = concept.ownObjectsIterator();
             int no = 1;
             while(it2.hasNext()){
        ContextEntity obj = (ContextEntity) it2.next();
        sb.append(obj.getName());
             }
       */
      sb.append(")");

      return sb.toString();
    }

  }

}
