package edu.mayo.bmi.guoqian.fca.fcaviewtab;

import java.awt.BorderLayout;
import javax.swing.JLabel;
import edu.stanford.smi.protege.widget.AbstractTabWidget;

/**
 * <p>タイトル: FCAView Tab</p>
 * <p>説明: Context-based ontolgoy building using formal concept analysis</p>
 * <p>著作権: Copyright (c) 2005</p>
 * <p>会社名: Department of Medical Informatics, Hokkaido University Graudate School of Medicine</p>
 * @author Guoqian Jiang
 * @version 1.0
 */

/**
 * <p>Copyright (c) 2016</p>
 * @author Richard Fallon, Sheffield Hallam University
 * @version 2.0
 * Extended FCAView to implement the following;
 * (i)  Protegé 3.5
 * (ii) Formal Concept Analysis of Conceptual Graphs imported into Protegé using; https://github.com/RichardFallon/CGImport
 */

public class FCAViewTab extends AbstractTabWidget {
	private static final long serialVersionUID = 1L;
	private FCAViewPanel FCAViewPanel;
	public void initialize() {
		setLabel("FCAView");
		add(new JLabel("FCAView"));
		
        // add UI components
        setLayout(new BorderLayout());

        FCAViewPanel = new FCAViewPanel(getKnowledgeBase());
        add(FCAViewPanel,BorderLayout.WEST);
	}   
        
  

	public static void main(String[] args) {
		edu.stanford.smi.protege.Application.main(args);
	}
	
}
/*

import java.io.PrintWriter;
import java.util.Iterator;

import javax.swing.JFileChooser;

import edu.stanford.smi.protege.Application;
import edu.stanford.smi.protege.model.Cls;
import edu.stanford.smi.protege.model.Project;
import edu.stanford.smi.protege.plugin.ExportPlugin;
import edu.stanford.smi.protege.util.ComponentFactory;
import edu.stanford.smi.protege.util.FileUtilities;
public class HelloWorldTab implements ExportPlugin {
    private static final String EXTENSION = ".foo";

    public String getName() {
        return "FooFile";
    }

    public void handleExportRequest(Project project) {
        File file = promptForFooFile(project);
        if (file != null) {
            saveToFile(project, file);
        }
    }

    public void dispose() {
        // do nothing
    }
    
    public static void main(String[] args) {
    	edu.stanford.smi.protege.Application.main(args);
    }
    
    private File promptForFooFile(Project project) {
        String name = project.getName();
        String proposedName = new File(name + EXTENSION).getPath();
        JFileChooser chooser = ComponentFactory.createFileChooser(proposedName, EXTENSION);
        File file = null;
        if (chooser.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {
            file = chooser.getSelectedFile();
        }
        return file;
     }
    
    private void saveToFile(Project project, File file) {
        PrintWriter writer = FileUtilities.createPrintWriter(file, false);
        saveProject(project, writer);
        writer.close();
    }
    
    // Write out each class, one per line.
    private void saveProject(Project project, PrintWriter writer) {
        Iterator i = project.getKnowledgeBase().getClses().iterator();
        while (i.hasNext()) {
            Cls cls = (Cls) i.next();
            if (!cls.isIncluded()) {
                writer.println(cls.getName());
        	}
        }
    }
}
*/